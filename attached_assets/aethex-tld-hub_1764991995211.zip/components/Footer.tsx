
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-brand-dark mt-12">
      <div className="container mx-auto px-4 py-6 text-center text-brand-text-secondary">
        <p>&copy; {new Date().getFullYear()} Aethex Foundation. All rights reserved.</p>
        <p className="text-sm mt-1">A decentralized naming system for the new internet.</p>
      </div>
    </footer>
  );
};

export default Footer;
