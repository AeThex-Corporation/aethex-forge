
import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { useWeb3 } from '../hooks/useWeb3';

interface NavItemProps {
  to: string;
  children: React.ReactNode;
  onClick?: () => void;
}

const NavItem: React.FC<NavItemProps> = ({ to, children, onClick }) => {
  return (
    <NavLink
      to={to}
      onClick={onClick}
      className={({ isActive }) =>
        `px-3 py-2 rounded-md text-sm font-medium transition-colors block md:inline-block ${
          isActive ? 'text-white bg-brand-primary' : 'text-brand-text-secondary hover:text-white hover:bg-brand-surface'
        }`
      }
    >
      {children}
    </NavLink>
  );
};


const ConnectWalletButton = () => {
    const { isConnected, address, connectWallet, disconnectWallet } = useWeb3();

    if (isConnected && address) {
        return (
            <div className="flex items-center space-x-2">
                <span className="hidden sm:inline px-3 py-2 text-sm font-mono bg-brand-surface rounded-md text-brand-light">
                    {`${address.substring(0, 6)}...${address.substring(address.length - 4)}`}
                </span>
                <button
                    onClick={disconnectWallet}
                    className="px-4 py-2 text-sm font-medium text-white bg-red-600 hover:bg-red-700 rounded-md transition-colors"
                >
                    Disconnect
                </button>
            </div>
        );
    }

    return (
        <button
            onClick={connectWallet}
            className="px-4 py-2 text-sm font-medium text-white bg-brand-primary hover:bg-brand-secondary rounded-md transition-colors shadow-lg whitespace-nowrap"
        >
            Connect Wallet
        </button>
    );
};

const Navbar: React.FC = () => {
    const { isConnected, isAdmin } = useWeb3();
    const [isMenuOpen, setIsMenuOpen] = useState(false);

    const toggleMenu = () => setIsMenuOpen(!isMenuOpen);
    const closeMenu = () => setIsMenuOpen(false);

  return (
    <nav className="glassmorphism shadow-xl sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-8">
            <NavLink to="/" className="text-white text-xl font-bold transition-transform hover:scale-105" onClick={closeMenu}>
              .aethex
            </NavLink>
            <div className="hidden md:flex items-baseline space-x-4">
              <NavItem to="/">Register</NavItem>
              {isConnected && <NavItem to="/dashboard">My Domains</NavItem>}
              <NavItem to="/guide">Guide</NavItem>
              <NavItem to="/agora">Agora</NavItem>
              <NavItem to="/grants">Grants</NavItem>
              {isAdmin && <NavItem to="/admin">Admin</NavItem>}
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <ConnectWalletButton />
            <button
                onClick={toggleMenu}
                className="md:hidden p-2 rounded-md text-brand-text-secondary hover:text-white hover:bg-brand-surface focus:outline-none transition-colors"
                aria-label="Toggle menu"
            >
                <div className="w-6 h-6 relative flex items-center justify-center">
                    <span className={`transform transition-all duration-300 absolute h-0.5 w-6 bg-current ${isMenuOpen ? 'rotate-45 translate-y-0' : '-translate-y-2'}`}></span>
                    <span className={`transform transition-all duration-300 absolute h-0.5 w-6 bg-current ${isMenuOpen ? 'opacity-0' : 'opacity-100'}`}></span>
                    <span className={`transform transition-all duration-300 absolute h-0.5 w-6 bg-current ${isMenuOpen ? '-rotate-45 translate-y-0' : 'translate-y-2'}`}></span>
                </div>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <div 
        className={`md:hidden absolute w-full bg-brand-background/95 backdrop-blur-md border-t border-brand-primary/20 z-40 transition-all duration-300 ease-in-out origin-top overflow-hidden ${
          isMenuOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0 pointer-events-none'
        }`}
      >
          <div className="px-4 pt-2 pb-4 space-y-1 shadow-inner">
            <NavItem to="/" onClick={closeMenu}>Register</NavItem>
            {isConnected && <NavItem to="/dashboard" onClick={closeMenu}>My Domains</NavItem>}
            <NavItem to="/guide" onClick={closeMenu}>Guide</NavItem>
            <NavItem to="/agora" onClick={closeMenu}>Agora</NavItem>
            <NavItem to="/grants" onClick={closeMenu}>Grants</NavItem>
            {isAdmin && <NavItem to="/admin" onClick={closeMenu}>Admin</NavItem>}
          </div>
      </div>
    </nav>
  );
};

export default Navbar;
