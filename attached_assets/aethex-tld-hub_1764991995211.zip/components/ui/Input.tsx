
import React from 'react';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  className?: string;
}

const Input: React.FC<InputProps> = ({ label, className = '', id, ...props }) => {
  return (
    <div className="w-full">
      {label && <label htmlFor={id} className="block text-sm font-medium text-brand-text-secondary mb-1">{label}</label>}
      <input
        id={id}
        className={`w-full bg-brand-background border border-brand-primary/50 rounded-md py-2 px-3 text-brand-light placeholder-brand-text-secondary/50 focus:ring-brand-secondary focus:border-brand-secondary transition-colors ${className}`}
        {...props}
      />
    </div>
  );
};


interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  className?: string;
}

export const Textarea: React.FC<TextareaProps> = ({ label, className = '', id, ...props }) => {
  return (
    <div className="w-full">
      {label && <label htmlFor={id} className="block text-sm font-medium text-brand-text-secondary mb-1">{label}</label>}
      <textarea
        id={id}
        rows={4}
        className={`w-full bg-brand-background border border-brand-primary/50 rounded-md py-2 px-3 text-brand-light placeholder-brand-text-secondary/50 focus:ring-brand-secondary focus:border-brand-secondary transition-colors ${className}`}
        {...props}
      />
    </div>
  );
};


export default Input;
