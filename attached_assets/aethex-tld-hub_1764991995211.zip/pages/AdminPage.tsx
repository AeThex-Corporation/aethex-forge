
import React, { useState, useEffect } from 'react';
import { useWeb3 } from '../hooks/useWeb3';
import { getPricingConfig, updatePricingConfig } from '../services/mockApi';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';

const AdminDirectMint: React.FC = () => {
    return (
        <Card>
            <h3 className="text-xl font-bold text-white mb-4">Direct Mint Domain</h3>
            <div className="space-y-4">
                <Input label="Domain Name (e.g., 'studio')" placeholder="studio" />
                <Input label="Recipient Wallet Address" placeholder="0x..." />
                <Button>Mint for Free (Gas Only)</Button>
            </div>
        </Card>
    );
};

const AdminPricingConfig: React.FC = () => {
    const [prices, setPrices] = useState({ char2: 1.0, char3_4: 0.1, char5_plus: 0.01 });
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);
    const [message, setMessage] = useState('');

    useEffect(() => {
        const fetchPricing = async () => {
            try {
                const config = await getPricingConfig();
                setPrices(config);
            } catch (e) {
                console.error("Failed to load pricing config", e);
            } finally {
                setIsLoading(false);
            }
        };
        fetchPricing();
    }, []);

    const handleChange = (key: keyof typeof prices, value: string) => {
        setPrices(prev => ({ ...prev, [key]: parseFloat(value) }));
    };

    const handleUpdate = async () => {
        setIsSaving(true);
        setMessage('');
        try {
            await updatePricingConfig(prices);
            setMessage('Pricing configuration updated successfully.');
        } catch (error) {
            setMessage('Error updating pricing configuration.');
        } finally {
            setIsSaving(false);
        }
    };

    if (isLoading) {
        return (
            <Card>
                <div className="animate-pulse space-y-4">
                    <div className="h-6 w-1/3 bg-brand-surface rounded"></div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="h-10 w-full bg-brand-surface rounded"></div>
                        <div className="h-10 w-full bg-brand-surface rounded"></div>
                        <div className="h-10 w-full bg-brand-surface rounded"></div>
                    </div>
                </div>
            </Card>
        );
    }

    return (
        <Card>
            <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold text-white">Registration Pricing</h3>
                <span className="text-xs text-brand-text-secondary bg-brand-background px-2 py-1 rounded">Base currency: ETH</span>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <Input 
                    label="2 Characters" 
                    type="number" 
                    step="0.1"
                    min="0"
                    value={prices.char2}
                    onChange={(e) => handleChange('char2', e.target.value)}
                />
                <Input 
                    label="3-4 Characters" 
                    type="number" 
                    step="0.01"
                    min="0"
                    value={prices.char3_4}
                    onChange={(e) => handleChange('char3_4', e.target.value)}
                />
                <Input 
                    label="5+ Characters" 
                    type="number" 
                    step="0.001"
                    min="0"
                    value={prices.char5_plus}
                    onChange={(e) => handleChange('char5_plus', e.target.value)}
                />
            </div>

            <div className="flex flex-col sm:flex-row justify-between items-center gap-4 border-t border-brand-primary/20 pt-4">
                 <p className="text-sm text-brand-text-secondary italic">
                    Note: Pricing updates affect new registrations immediately.
                </p>
                <div className="flex items-center space-x-4 w-full sm:w-auto justify-end">
                    {message && (
                        <span className={`text-sm ${message.includes('Error') ? 'text-red-400' : 'text-green-400'}`}>
                            {message}
                        </span>
                    )}
                    <Button onClick={handleUpdate} isLoading={isSaving}>Update Pricing</Button>
                </div>
            </div>
        </Card>
    );
};

const AdminPage: React.FC = () => {
  const { isAdmin, isConnected, address } = useWeb3();
  const [activeTab, setActiveTab] = useState('mint');

  if (!isConnected || !isAdmin) {
    return (
      <div className="text-center animate-fade-in">
        <h2 className="text-3xl font-bold text-white">Admin Access Required</h2>
        <p className="mt-2 text-brand-text-secondary">
            This area is restricted. Please connect with the admin wallet.
            {address && <span className="block mt-2 font-mono text-sm text-red-400">Connected as: {address}</span>}
        </p>
      </div>
    );
  }
  
  const TabButton = ({ id, label }: { id: string, label: string }) => (
      <button onClick={() => setActiveTab(id)} className={`px-4 py-2 text-sm font-medium rounded-md ${activeTab === id ? 'bg-brand-primary text-white' : 'text-brand-text-secondary hover:bg-brand-surface'}`}>
          {label}
      </button>
  );

  return (
    <div className="animate-fade-in">
      <h1 className="text-4xl font-bold text-white mb-6">TLD Admin Panel</h1>
      <div className="flex space-x-2 bg-brand-dark p-1 rounded-lg mb-6 max-w-md">
        <TabButton id="mint" label="Direct Mint" />
        <TabButton id="pricing" label="Pricing" />
      </div>
      
      <div>
        {activeTab === 'mint' && <AdminDirectMint />}
        {activeTab === 'pricing' && <AdminPricingConfig />}
      </div>
    </div>
  );
};

export default AdminPage;
