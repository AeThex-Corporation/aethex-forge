
import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getProposalById, submitVote } from '../services/mockApi';
import { Proposal, ProposalStatus } from '../types';
import { useWeb3 } from '../hooks/useWeb3';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';

const VoteProgressBar: React.FC<{ votes: Proposal['votes'] }> = ({ votes }) => {
    const total = votes.for + votes.against + votes.abstain;
    if (total === 0) return <div className="h-4 bg-gray-700 rounded-full" />;

    const forPct = (votes.for / total) * 100;
    const againstPct = (votes.against / total) * 100;

    return (
        <div className="w-full flex h-4 bg-brand-dark rounded-full overflow-hidden my-2">
            <div className="bg-green-500" style={{ width: `${forPct}%` }}></div>
            <div className="bg-red-500" style={{ width: `${againstPct}%` }}></div>
        </div>
    );
};


const ProposalDetailPage: React.FC = () => {
    const { id } = useParams<{ id: string }>();
    const navigate = useNavigate();
    const { isConnected, votingPower, connectWallet } = useWeb3();
    const [proposal, setProposal] = useState<Proposal | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [isVoting, setIsVoting] = useState(false);
    const [voted, setVoted] = useState(false);

    const fetchProposal = useCallback(async () => {
        if (!id) return;
        setIsLoading(true);
        const data = await getProposalById(id);
        if (data) {
            setProposal(data);
        } else {
            // handle not found, maybe navigate back
        }
        setIsLoading(false);
    }, [id]);

    useEffect(() => {
        fetchProposal();
    }, [fetchProposal]);

    const handleVote = async (vote: 'for' | 'against' | 'abstain') => {
        if (!id || !proposal || proposal.status !== ProposalStatus.Active || !isConnected) return;
        setIsVoting(true);
        const updatedProposal = await submitVote(id, vote, votingPower);
        setProposal(updatedProposal);
        setVoted(true);
        setIsVoting(false);
    };

    if (isLoading) return <div className="text-center">Loading proposal...</div>;
    if (!proposal) return <div className="text-center">Proposal not found.</div>;
    
    const canVote = isConnected && proposal.status === ProposalStatus.Active && !voted;

    return (
        <div className="animate-fade-in">
            <Button variant="secondary" onClick={() => navigate('/agora')} className="mb-6">
              &larr; Back to Agora
            </Button>
            <Card>
                <h1 className="text-3xl font-bold text-white mb-2">{proposal.title}</h1>
                <p className="text-sm text-brand-text-secondary mb-4">Proposed by: <span className="font-mono">{proposal.proposer}</span></p>
                <p className="text-brand-text leading-relaxed whitespace-pre-wrap">{proposal.description}</p>
                
                <div className="my-6">
                    <h3 className="font-semibold text-white">Current Votes</h3>
                    <VoteProgressBar votes={proposal.votes} />
                    <div className="flex justify-between text-sm mt-1">
                        <span className="text-green-400">For: {proposal.votes.for.toLocaleString()}</span>
                        <span className="text-red-400">Against: {proposal.votes.against.toLocaleString()}</span>
                        <span className="text-gray-400">Abstain: {proposal.votes.abstain.toLocaleString()}</span>
                    </div>
                </div>

                {proposal.status === ProposalStatus.Active && (
                    <Card className="bg-brand-dark mt-6">
                        <h3 className="text-xl font-bold text-white mb-4">Cast Your Vote</h3>
                        {!isConnected ? (
                             <Button onClick={connectWallet}>Connect Wallet to Vote</Button>
                        ) : voted ? (
                            <p className="text-green-400">Thank you for voting!</p>
                        ) : (
                            <>
                            <p className="text-brand-text-secondary mb-4">Your voting power: <span className="font-bold text-white">{votingPower.toLocaleString()}</span></p>
                            <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4">
                                <Button className="w-full" onClick={() => handleVote('for')} isLoading={isVoting} disabled={!canVote}>For</Button>
                                <Button className="w-full" variant="danger" onClick={() => handleVote('against')} isLoading={isVoting} disabled={!canVote}>Against</Button>
                                <Button className="w-full" variant="secondary" onClick={() => handleVote('abstain')} isLoading={isVoting} disabled={!canVote}>Abstain</Button>
                            </div>
                            </>
                        )}
                    </Card>
                )}
            </Card>
        </div>
    );
};

export default ProposalDetailPage;