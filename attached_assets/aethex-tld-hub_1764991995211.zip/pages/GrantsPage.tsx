
import React, { useState, useEffect, useCallback } from 'react';
import { useForm } from 'react-hook-form';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Input, { Textarea } from '../components/ui/Input';
import { useWeb3 } from '../hooks/useWeb3';
import { GrantApplication } from '../types';
import { submitGrantApplication, getUserGrants } from '../services/mockApi';

type GrantFormData = {
    projectName: string;
    teamDetails: string;
    projectDescription: string;
    fundingAmount: number;
};

const ApplyGrantForm: React.FC<{ onSuccessfulSubmit: () => void }> = ({ onSuccessfulSubmit }) => {
    const { register, handleSubmit, formState: { errors }, reset } = useForm<GrantFormData>();
    const { address, isConnected, connectWallet } = useWeb3();
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [submitMessage, setSubmitMessage] = useState('');

    const onSubmit = async (data: GrantFormData) => {
        if (!isConnected || !address) {
            connectWallet();
            return;
        }
        setIsSubmitting(true);
        setSubmitMessage('');
        try {
            await submitGrantApplication({ ...data, applicantAddress: address });
            setSubmitMessage('Your grant application has been submitted successfully!');
            reset();
            onSuccessfulSubmit();
        } catch (error) {
            setSubmitMessage('Failed to submit application. Please try again.');
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <Card>
            <h2 className="text-2xl font-bold text-white mb-4">Submit Your Proposal</h2>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                <Input label="Project Name" id="projectName" {...register('projectName', { required: true })} />
                {errors.projectName && <span className="text-red-400 text-sm">This field is required</span>}
                
                <Textarea label="Team Details" id="teamDetails" {...register('teamDetails', { required: true })} />
                {errors.teamDetails && <span className="text-red-400 text-sm">This field is required</span>}

                <Textarea label="Project Description" id="projectDescription" {...register('projectDescription', { required: true })} />
                {errors.projectDescription && <span className="text-red-400 text-sm">This field is required</span>}

                <Input label="Funding Amount (USDC)" id="fundingAmount" type="number" {...register('fundingAmount', { required: true, valueAsNumber: true, min: 1 })} />
                {errors.fundingAmount && <span className="text-red-400 text-sm">Please enter a valid amount</span>}

                <Button type="submit" isLoading={isSubmitting} disabled={!isConnected}>
                    {isConnected ? 'Submit Application' : 'Connect Wallet to Apply'}
                </Button>
                {submitMessage && <p className="text-brand-light mt-4">{submitMessage}</p>}
            </form>
        </Card>
    );
};

const MyGrants: React.FC<{ grants: GrantApplication[] }> = ({ grants }) => {
    return (
        <Card className="mt-12">
            <h2 className="text-2xl font-bold text-white mb-4">My Applications</h2>
            {grants.length === 0 ? (
                <p className="text-brand-text-secondary">You haven't submitted any grant applications.</p>
            ) : (
                <div className="space-y-4">
                    {grants.map(grant => (
                        <div key={grant.id} className="p-4 rounded-md bg-brand-dark flex justify-between items-center">
                            <div>
                                <p className="font-bold text-white">{grant.projectName}</p>
                                <p className="text-sm text-brand-text-secondary">Requested: ${grant.fundingAmount.toLocaleString()} USDC</p>
                            </div>
                            <span className={`text-sm font-semibold px-3 py-1 rounded-full ${
                                grant.status === 'Approved' ? 'bg-green-500/20 text-green-400' : 
                                grant.status === 'Rejected' ? 'bg-red-500/20 text-red-400' : 'bg-blue-500/20 text-blue-400'
                            }`}>{grant.status}</span>
                        </div>
                    ))}
                </div>
            )}
        </Card>
    )
}

const GrantsPage: React.FC = () => {
    const { isConnected, address } = useWeb3();
    const [myGrants, setMyGrants] = useState<GrantApplication[]>([]);
    
    const fetchMyGrants = useCallback(async () => {
        if(isConnected && address) {
            const userGrants = await getUserGrants(address);
            setMyGrants(userGrants);
        }
    }, [isConnected, address]);

    useEffect(() => {
        fetchMyGrants();
    }, [fetchMyGrants]);

    return (
        <div className="animate-fade-in">
            <div className="text-center mb-12">
                <h1 className="text-4xl font-bold text-white">Developer Grant Program</h1>
                <p className="mt-2 max-w-3xl mx-auto text-brand-text-secondary">
                    Help us build the future of the decentralized web. We're funding innovative projects that expand the .aethex ecosystem.
                </p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div>
                    <h2 className="text-2xl font-bold text-white mb-4">Focus Areas & Funding</h2>
                    <Card>
                        <ul className="space-y-4 text-brand-text">
                            <li><strong>Wallet Integrations:</strong> Add .aethex support to existing wallets.</li>
                            <li><strong>dApp Tooling:</strong> Libraries and frameworks for .aethex-native dApps.</li>
                            <li><strong>Community & Education:</strong> Create resources to grow our community.</li>
                        </ul>
                        <div className="mt-6 pt-6 border-t border-brand-primary/20 space-y-4">
                            <p><strong>Level 1:</strong> Up to $10,000 USDC for smaller projects and proofs-of-concept.</p>
                            <p><strong>Level 2:</strong> Up to $30,000 USDC for more established teams and complex projects.</p>
                        </div>
                    </Card>
                </div>
                <ApplyGrantForm onSuccessfulSubmit={fetchMyGrants} />
            </div>
            {isConnected && <MyGrants grants={myGrants} />}
        </div>
    );
};

export default GrantsPage;