
import { GoogleGenAI, Chat, GenerateContentResponse, FunctionDeclaration } from "@google/genai";
import type { ChatMessage } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Mock functions to simulate on-chain data retrieval
const executeTool = (name: string, args: any) => {
  console.log(`Executing tool: ${name}`, args);
  switch (name) {
    case 'get_account_balance':
      return { balance: `${(Math.random() * 1000000).toFixed(2)} AETH` };
    case 'get_transaction_details':
      return {
        from: args.tx_hash.slice(0, 10) + '...',
        to: '0x' + [...Array(40)].map(() => Math.floor(Math.random() * 16).toString(16)).join(''),
        value: `${(Math.random() * 100).toFixed(2)} AETH`,
        status: Math.random() > 0.1 ? 'Success' : 'Failed'
      };
    case 'get_erc20_token_balance':
      return { balance: `${(Math.random() * 50000).toFixed(4)} USDC` };
    default:
      return { error: `Tool ${name} not found.` };
  }
};

export const generateTitle = async (userMessage: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Generate a short, concise, and descriptive title (max 5 words) for a chat conversation that starts with this message: "${userMessage}". Do not use quotes.`,
    });
    return response.text?.trim() || userMessage.slice(0, 30);
  } catch (error) {
    console.error("Error generating title:", error);
    return userMessage.slice(0, 30) + (userMessage.length > 30 ? '...' : '');
  }
};

export const runChat = async (
    prompt: string, 
    history: ChatMessage[], 
    systemInstruction?: string,
    tools?: FunctionDeclaration[]
): Promise<string> => {
  
  const chat: Chat = ai.chats.create({
    model: 'gemini-2.5-pro',
    config: {
        tools: tools && tools.length > 0 ? [{ functionDeclarations: tools }] : undefined,
        systemInstruction: systemInstruction
    },
    history: history.map(msg => ({
      role: msg.role,
      parts: [{ text: msg.content }]
    }))
  });

  let response: GenerateContentResponse = await chat.sendMessage({ message: prompt });
  let text = response.text;
  
  if (response.functionCalls && response.functionCalls.length > 0) {
    const functionCalls = response.functionCalls;
    console.log("Model requested function calls:", functionCalls);

    const functionResponseParts = functionCalls.map(fc => {
      const result = executeTool(fc.name, fc.args);
      return {
        functionResponse: {
          name: fc.name,
          response: { result },
        },
      };
    });

    console.log("Sending tool responses back to model:", functionResponseParts);
    const result2 = await chat.sendMessage({ message: functionResponseParts });
    text = result2.text;
  }

  if (!text) {
      return "I was not able to generate a response. Please try again."
  }
  
  return text;
};
