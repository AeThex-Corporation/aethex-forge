
import { FunctionDeclaration } from '@google/genai';

export interface ChatMessage {
  role: 'user' | 'model';
  content: string;
}

export interface PersonaTheme {
  primary: string;      // Text color for accents (e.g., "text-cyan-400")
  gradient: string;     // Header text gradient (e.g., "from-cyan-400 to-purple-500")
  avatar: string;       // Avatar background gradient (e.g., "from-cyan-500 to-purple-600")
  button: string;       // Button background (e.g., "bg-purple-600 hover:bg-purple-700")
}

export interface Persona {
  id: string;
  name: string;
  description: string;
  systemInstruction: string;
  initialMessage: string;
  tools?: FunctionDeclaration[];
  icon: 'logo' | 'shield' | 'hammer' | 'building' | 'book' | 'chart' | 'music' | 'scroll' | 'wave' | 'money';
  theme: PersonaTheme;
  capabilities: string[];
  limitations: string[];
  requiredTier?: 'Free' | 'Architect' | 'Council';
}

export interface ChatSession {
    id: string;
    personaId: string;
    title: string;
    messages: ChatMessage[];
    timestamp: number;
}

export interface User {
    id: string;
    name: string;
    email: string;
    tier: 'Free' | 'Architect' | 'Council';
    avatar?: string;
}
