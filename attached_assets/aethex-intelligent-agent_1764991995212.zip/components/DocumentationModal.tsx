
import React from 'react';
import { PERSONAS } from '../constants';
import { XIcon, AethexLogo, ShieldIcon, HammerIcon, BuildingIcon, BookIcon, ChartIcon, MusicIcon, ScrollIcon, WaveIcon, MoneyIcon } from './Icons';
import { Persona } from '../types';

interface DocumentationModalProps {
    isOpen: boolean;
    onClose: () => void;
}

export const DocumentationModal: React.FC<DocumentationModalProps> = ({ isOpen, onClose }) => {
    if (!isOpen) return null;

    const getIcon = (persona: Persona) => {
        switch (persona.icon) {
            case 'logo': return AethexLogo;
            case 'shield': return ShieldIcon;
            case 'hammer': return HammerIcon;
            case 'building': return BuildingIcon;
            case 'book': return BookIcon;
            case 'chart': return ChartIcon;
            case 'music': return MusicIcon;
            case 'scroll': return ScrollIcon;
            case 'wave': return WaveIcon;
            case 'money': return MoneyIcon;
            default: return AethexLogo;
        }
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <div className="bg-gray-900 rounded-xl border border-gray-700 w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl">
                <div className="flex items-center justify-between p-6 border-b border-gray-800 bg-gray-900/50">
                    <h2 className="text-2xl font-bold text-white tracking-wide">Ecosystem Agents Documentation</h2>
                    <button 
                        onClick={onClose} 
                        className="text-gray-400 hover:text-white transition-colors p-1 hover:bg-gray-800 rounded-full"
                    >
                        <XIcon className="w-6 h-6" />
                    </button>
                </div>

                <div className="flex-1 overflow-y-auto p-6 space-y-6">
                    <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2">
                        {PERSONAS.map(persona => {
                            const Icon = getIcon(persona);
                            return (
                                <div 
                                    key={persona.id} 
                                    className="bg-gray-800/50 rounded-xl border border-gray-700 p-6 hover:border-gray-600 transition-colors"
                                >
                                    <div className="flex items-center gap-3 mb-4">
                                        <div className={`p-2 rounded-lg bg-gray-900 border border-gray-700 ${persona.theme.primary}`}>
                                            <Icon className="w-6 h-6" />
                                        </div>
                                        <div>
                                            <h3 className={`text-lg font-bold bg-clip-text text-transparent bg-gradient-to-r ${persona.theme.gradient}`}>
                                                {persona.name}
                                            </h3>
                                            <p className="text-sm text-gray-400">{persona.description}</p>
                                        </div>
                                    </div>

                                    <div className="space-y-4">
                                        <div>
                                            <h4 className={`text-xs font-bold uppercase tracking-wider mb-2 ${persona.theme.primary}`}>Capabilities</h4>
                                            <ul className="space-y-1">
                                                {persona.capabilities.map((cap, idx) => (
                                                    <li key={idx} className="text-sm text-gray-300 flex items-start gap-2">
                                                        <span className="text-gray-500 mt-1">•</span>
                                                        {cap}
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>

                                        <div>
                                            <h4 className="text-xs font-bold uppercase tracking-wider mb-2 text-gray-500">Limitations</h4>
                                            <ul className="space-y-1">
                                                {persona.limitations.map((lim, idx) => (
                                                    <li key={idx} className="text-sm text-gray-400 flex items-start gap-2">
                                                        <span className="text-gray-600 mt-1">•</span>
                                                        {lim}
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>
                
                <div className="p-4 border-t border-gray-800 text-center text-xs text-gray-500 bg-gray-900/50">
                    Powered by Aethex Intelligent Ecosystem & Google Gemini
                </div>
            </div>
        </div>
    );
};
