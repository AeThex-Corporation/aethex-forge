
import React, { useState } from 'react';
import { XIcon, AethexLogo } from './Icons';
import { supabase } from '../services/supabaseClient';

interface AuthModalProps {
    isOpen: boolean;
    onClose: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [isSignUp, setIsSignUp] = useState(false);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    if (!isOpen) return null;

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError(null);

        try {
            if (isSignUp) {
                const { error } = await supabase.auth.signUp({
                    email,
                    password,
                    options: {
                        data: {
                            full_name: name,
                            tier: 'Free' // Default tier
                        }
                    }
                });
                if (error) throw error;
                // For many Supabase setups, signup requires email verification. 
                // We'll show a message if no error occurred.
                if (!error) {
                    // Optionally close or show verification message
                    onClose(); 
                }
            } else {
                const { error } = await supabase.auth.signInWithPassword({
                    email,
                    password
                });
                if (error) throw error;
                onClose();
            }
        } catch (err: any) {
            setError(err.message || 'An error occurred during authentication.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <div className="bg-gray-900 rounded-2xl border border-gray-800 w-full max-w-md shadow-2xl overflow-hidden relative">
                {/* Close Button */}
                <button 
                    onClick={onClose}
                    className="absolute top-4 right-4 text-gray-500 hover:text-white transition-colors"
                >
                    <XIcon className="w-6 h-6" />
                </button>

                <div className="p-8 text-center">
                    <div className="inline-flex items-center justify-center p-3 rounded-xl bg-gray-800 border border-gray-700 mb-6 shadow-lg">
                        <AethexLogo className="w-10 h-10 text-cyan-400" />
                    </div>
                    
                    <h2 className="text-2xl font-bold text-white mb-2">
                        Aethex Passport
                    </h2>
                    <p className="text-gray-400 text-sm mb-8">
                        {isSignUp ? 'Join the ecosystem to build the future.' : 'Sign in to access your dashboard.'}
                    </p>

                    {error && (
                        <div className="mb-4 p-3 bg-red-900/30 border border-red-800 text-red-300 text-sm rounded-lg">
                            {error}
                        </div>
                    )}

                    <form onSubmit={handleSubmit} className="space-y-4 text-left">
                        {isSignUp && (
                            <div>
                                <label className="block text-xs font-semibold text-gray-500 uppercase mb-1 ml-1">Full Name</label>
                                <input 
                                    type="text" 
                                    value={name}
                                    onChange={(e) => setName(e.target.value)}
                                    placeholder="Jane Doe"
                                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500 outline-none transition-all placeholder-gray-600"
                                    required={isSignUp}
                                />
                            </div>
                        )}
                        
                        <div>
                            <label className="block text-xs font-semibold text-gray-500 uppercase mb-1 ml-1">Email Address</label>
                            <input 
                                type="email" 
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                placeholder="jane@example.com"
                                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500 outline-none transition-all placeholder-gray-600"
                                required
                            />
                        </div>

                        <div>
                            <label className="block text-xs font-semibold text-gray-500 uppercase mb-1 ml-1">Password</label>
                            <input 
                                type="password" 
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                placeholder="••••••••"
                                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500 outline-none transition-all placeholder-gray-600"
                                required
                                minLength={6}
                            />
                        </div>

                        <button 
                            type="submit"
                            disabled={loading}
                            className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold py-3 rounded-lg transition-all transform active:scale-95 shadow-lg shadow-cyan-900/20 disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            {loading ? 'Processing...' : (isSignUp ? 'Create Passport' : 'Sign In')}
                        </button>
                    </form>

                    <div className="mt-6 text-sm text-gray-500">
                        {isSignUp ? 'Already have a passport?' : "Don't have a passport?"} {' '}
                        <button 
                            onClick={() => {
                                setIsSignUp(!isSignUp);
                                setError(null);
                            }}
                            className="text-cyan-400 hover:text-cyan-300 font-medium transition-colors"
                        >
                            {isSignUp ? 'Sign In' : 'Sign Up'}
                        </button>
                    </div>
                </div>
                
                <div className="bg-gray-950/50 p-4 border-t border-gray-800 text-center text-xs text-gray-600">
                    By continuing, you agree to the Axiom Ethics Policy.
                </div>
            </div>
        </div>
    );
};
