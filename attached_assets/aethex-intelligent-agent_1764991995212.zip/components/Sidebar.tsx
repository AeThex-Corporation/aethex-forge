
import React from 'react';
import { ChatSession, User } from '../types';
import { AethexLogo, PlusIcon, MessageIcon, TrashIcon, HistoryIcon, LogOutIcon, SettingsIcon } from './Icons';

interface SidebarProps {
  sessions: ChatSession[];
  activeSessionId: string | null;
  onSelectSession: (id: string) => void;
  onNewChat: () => void;
  onDeleteSession: (e: React.MouseEvent, id: string) => void;
  isOpen: boolean;
  onCloseMobile: () => void;
  user: User | null;
  onSignIn: () => void;
  onSignOut: () => void;
  onSettingsClick: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
    sessions, 
    activeSessionId, 
    onSelectSession, 
    onNewChat, 
    onDeleteSession,
    isOpen,
    onCloseMobile,
    user,
    onSignIn,
    onSignOut,
    onSettingsClick
}) => {
  const getTierBadgeStyle = (tier: string) => {
      switch (tier) {
          case 'Council':
              return 'bg-purple-900/30 text-purple-400 border-purple-800';
          case 'Architect':
              return 'bg-cyan-900/30 text-cyan-400 border-cyan-800';
          default:
              return 'bg-gray-800 text-gray-400 border-gray-700';
      }
  };

  // Sort sessions by timestamp descending (most recent first)
  const sortedSessions = [...sessions].sort((a, b) => b.timestamp - a.timestamp);

  return (
    <>
        {/* Mobile Overlay */}
        {isOpen && (
            <div 
                className="fixed inset-0 bg-black/60 z-20 md:hidden backdrop-blur-sm"
                onClick={onCloseMobile}
            />
        )}

        {/* Sidebar Container */}
        <aside 
            className={`
                fixed md:static inset-y-0 left-0 z-30 w-72 
                bg-gray-950 border-r border-gray-800 
                transform transition-transform duration-300 ease-in-out
                flex flex-col
                ${isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
            `}
        >
            {/* Header */}
            <div className="p-4 flex items-center gap-3 border-b border-gray-800/50">
                <div className="p-2 bg-gray-900 rounded-lg border border-gray-800 text-cyan-400">
                    <AethexLogo className="w-6 h-6" />
                </div>
                <span className="text-lg font-bold text-white tracking-wide">Aethex</span>
            </div>

            {/* New Chat Button */}
            <div className="p-4">
                <button
                    onClick={() => {
                        onNewChat();
                        onCloseMobile();
                    }}
                    className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white p-3 rounded-xl transition-colors font-medium shadow-lg shadow-blue-900/20 border border-blue-500/50 hover:border-blue-400"
                >
                    <PlusIcon className="w-5 h-5" />
                    <span>New Chat</span>
                </button>
            </div>

            {/* History List */}
            <div className="flex-1 overflow-y-auto px-3 py-2 space-y-1">
                <div className="px-3 py-2 text-xs font-semibold text-gray-500 uppercase tracking-wider flex items-center gap-2">
                    <HistoryIcon className="w-3 h-3" />
                    Recent Activity
                </div>
                
                {sortedSessions.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-48 text-center px-6 opacity-60">
                        <div className="w-12 h-12 bg-gray-800/50 rounded-2xl flex items-center justify-center mb-3 border border-gray-700/50">
                             <MessageIcon className="w-5 h-5 text-gray-500" />
                        </div>
                        <h3 className="text-sm font-medium text-gray-300 mb-1">No chats yet</h3>
                        <p className="text-xs text-gray-500 leading-relaxed">
                            Start a new conversation to see your history here.
                        </p>
                    </div>
                ) : (
                    sortedSessions.map((session) => (
                        <div
                            key={session.id}
                            onClick={() => {
                                onSelectSession(session.id);
                                onCloseMobile();
                            }}
                            className={`
                                group flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-all duration-200
                                ${session.id === activeSessionId 
                                    ? 'bg-gray-800 text-white border border-gray-700 shadow-sm ring-1 ring-white/5' 
                                    : 'text-gray-500 hover:bg-gray-900 hover:text-gray-200 border border-transparent'}
                            `}
                        >
                            <MessageIcon className={`w-4 h-4 flex-shrink-0 transition-colors ${session.id === activeSessionId ? 'text-cyan-400' : 'text-gray-600 group-hover:text-gray-500'}`} />
                            <div className="flex-1 min-w-0">
                                <div className={`truncate text-sm font-medium ${session.id === activeSessionId ? 'text-white' : 'text-gray-400 group-hover:text-gray-300'}`}>
                                    {session.title || 'New Conversation'}
                                </div>
                                <div className="text-xs text-gray-600 truncate group-hover:text-gray-500">
                                    {new Date(session.timestamp).toLocaleDateString()}
                                </div>
                            </div>
                            <button
                                onClick={(e) => onDeleteSession(e, session.id)}
                                className={`
                                    p-1.5 rounded-md transition-all duration-200
                                    ${session.id === activeSessionId ? 'opacity-0 group-hover:opacity-100' : 'opacity-0 group-hover:opacity-100'}
                                    hover:bg-red-900/30 hover:text-red-400 text-gray-500
                                `}
                                title="Delete chat"
                            >
                                <TrashIcon className="w-4 h-4" />
                            </button>
                        </div>
                    ))
                )}
            </div>

            {/* User / Footer Section */}
            <div className="p-4 border-t border-gray-800 bg-gray-950/50">
                {user ? (
                    <div className="flex items-center gap-2 px-2">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-500 to-purple-600 shadow-inner flex items-center justify-center text-xs font-bold text-white flex-shrink-0">
                            {user.name.charAt(0)}
                        </div>
                        <div className="flex-1 min-w-0 mr-1">
                            <div className="text-sm font-medium text-white truncate">{user.name}</div>
                            <div className={`text-[10px] font-bold px-1.5 py-0.5 rounded border inline-block ${getTierBadgeStyle(user.tier)}`}>
                                {user.tier}
                            </div>
                        </div>
                        <div className="flex items-center gap-1">
                             <button 
                                onClick={onSettingsClick}
                                className="p-1.5 text-gray-500 hover:text-white hover:bg-gray-800 rounded-lg transition-colors"
                                title="Settings"
                            >
                                <SettingsIcon className="w-4 h-4" />
                            </button>
                            <button 
                                onClick={onSignOut}
                                className="p-1.5 text-gray-500 hover:text-white hover:bg-gray-800 rounded-lg transition-colors"
                                title="Sign Out"
                            >
                                <LogOutIcon className="w-4 h-4" />
                            </button>
                        </div>
                    </div>
                ) : (
                    <button 
                        onClick={onSignIn}
                        className="w-full flex items-center justify-center gap-2 bg-gray-800 hover:bg-gray-700 text-white py-2.5 px-4 rounded-xl transition-colors text-sm font-medium border border-gray-700"
                    >
                        <span>Sign In to Passport</span>
                    </button>
                )}
            </div>
        </aside>
    </>
  );
};
