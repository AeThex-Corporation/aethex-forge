
import React from 'react';
import type { ChatMessage as ChatMessageType, Persona } from '../types';
import { AethexLogo, ShieldIcon, HammerIcon, BuildingIcon, BookIcon, ChartIcon, MusicIcon, ScrollIcon, WaveIcon, MoneyIcon, UserIcon } from './Icons';

interface ChatMessageProps {
  message: ChatMessageType;
  currentPersona: Persona;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({ message, currentPersona }) => {
  const isUser = message.role === 'user';

  const getIcon = (iconName: string) => {
    switch(iconName) {
        case 'logo': return AethexLogo;
        case 'shield': return ShieldIcon;
        case 'hammer': return HammerIcon;
        case 'building': return BuildingIcon;
        case 'book': return BookIcon;
        case 'chart': return ChartIcon;
        case 'music': return MusicIcon;
        case 'scroll': return ScrollIcon;
        case 'wave': return WaveIcon;
        case 'money': return MoneyIcon;
        default: return AethexLogo;
    }
  };

  const Icon = getIcon(currentPersona.icon);

  const formatInline = (text: string, keyPrefix: string, isUserMsg: boolean) => {
    // 1. Images: ![alt](url)
    const imageRegex = /!\[([^\]]*)\]\(([^)]+)\)/g;
    const imgParts = text.split(imageRegex);

    if (imgParts.length > 1) {
         return imgParts.map((part, i) => {
            // The split result looks like: [text, alt, url, text, alt, url...]
            // This logic depends on how split works with capturing groups.
            // However, a safer way for React lists with capturing groups:
            // A matched regex split returns: [pre, capture1, capture2, post...]
            // So i % 3 === 0 is text, i % 3 === 1 is alt, i % 3 === 2 is url
            
            if (i % 3 === 0) {
                return formatInlineLinks(part, `${keyPrefix}-img-${i}`, isUserMsg);
            } else if (i % 3 === 1) {
                // This is the 'alt' part, wait for next iteration (url) to render
                return null; 
            } else {
                const alt = imgParts[i-1];
                const url = part;
                return (
                    <img 
                        key={`${keyPrefix}-img-tag-${i}`} 
                        src={url} 
                        alt={alt} 
                        className="max-w-full rounded-lg my-2 border border-gray-700 shadow-sm" 
                    />
                );
            }
         });
    }
    return formatInlineLinks(text, keyPrefix, isUserMsg);
  };

  const formatInlineLinks = (text: string, keyPrefix: string, isUserMsg: boolean) => {
      // 2. Links: [text](url)
      const linkRegex = /\[([^\]]+)\]\(([^)]+)\)/g;
      const linkParts = text.split(linkRegex);

      if (linkParts.length > 1) {
          return linkParts.map((part, i) => {
              if (i % 3 === 0) {
                  return formatInlineCode(part, `${keyPrefix}-link-${i}`, isUserMsg);
              } else if (i % 3 === 1) {
                  return null; // text part, wait for url
              } else {
                  const linkText = linkParts[i-1];
                  const url = part;
                  return (
                      <a 
                        key={`${keyPrefix}-link-tag-${i}`}
                        href={url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className={`underline underline-offset-2 decoration-1 transition-colors ${isUserMsg ? 'text-white decoration-white/50 hover:decoration-white' : 'text-cyan-400 decoration-cyan-400/50 hover:decoration-cyan-300'}`}
                      >
                          {linkText}
                      </a>
                  );
              }
          });
      }
      return formatInlineCode(text, keyPrefix, isUserMsg);
  };

  const formatInlineCode = (text: string, keyPrefix: string, isUserMsg: boolean) => {
    // 3. Inline Code: `code`
    const codeRegex = /`([^`]+)`/g;
    const parts = text.split(codeRegex);

    return parts.map((part, i) => {
        if (i % 2 === 1) {
            // Inline code style
            const codeClass = isUserMsg 
                ? "bg-black/20 text-white px-1.5 py-0.5 rounded text-sm font-mono"
                : "bg-gray-900/50 text-cyan-300 px-1.5 py-0.5 rounded text-sm font-mono border border-gray-700/50";
            return <code key={`${keyPrefix}-code-${i}`} className={codeClass}>{part}</code>;
        }

        // 4. Bold: **text**
        const boldRegex = /\*\*(.*?)\*\*/g;
        const boldParts = part.split(boldRegex);
        
        return boldParts.map((bPart, bI) => {
            if (bI % 2 === 1) {
                return <strong key={`${keyPrefix}-bold-${i}-${bI}`} className="font-bold">{bPart}</strong>;
            }
            
            // 5. Italic: *text*
            const italicRegex = /\*([^\*]+)\*/g;
            const italicParts = bPart.split(italicRegex);

            return italicParts.map((iPart, iI) => {
                if (iI % 2 === 1) {
                    return <em key={`${keyPrefix}-italic-${i}-${bI}-${iI}`} className="italic opacity-90">{iPart}</em>;
                }
                return <span key={`${keyPrefix}-text-${i}-${bI}-${iI}`}>{iPart}</span>;
            });
        });
    });
  };

  const formatContent = (content: string, isUserMsg: boolean) => {
    const codeBlockRegex = /```([\s\S]*?)```/g;
    const parts = content.split(codeBlockRegex);

    return parts.map((part, index) => {
        if (index % 2 === 1) {
            // Code block
            const preClass = isUserMsg
                ? "bg-black/20 p-3 rounded-md overflow-x-auto my-2 text-white/90"
                : "bg-gray-950 p-3 rounded-md overflow-x-auto my-2 border border-gray-800";
            const codeClass = isUserMsg
                ? "text-sm font-mono"
                : `text-sm font-mono ${currentPersona.theme.primary}`;
            
            return (
                <pre key={index} className={preClass}>
                    <code className={codeClass}>{part.trim()}</code>
                </pre>
            );
        }

        // Text content processing
        const lines = part.split('\n');
        return (
            <div key={index} className="whitespace-pre-wrap leading-relaxed">
                {lines.map((line, lineIdx) => {
                    // List detection
                    const listMatch = line.match(/^(\s*)([-*]|\d+\.)\s+(.+)/);
                    
                    if (listMatch) {
                         const [_, indent, marker, text] = listMatch;
                         const isOrdered = /^\d+\./.test(marker);
                         return (
                             <div key={lineIdx} className="flex items-start gap-2 ml-2 mb-1">
                                 <span className={`mt-1 text-xs opacity-70 flex-shrink-0 ${isOrdered ? '' : 'text-[8px] pt-1'}`}>
                                    {isOrdered ? marker : '●'}
                                 </span>
                                 <span className="flex-1 min-w-0 break-words">
                                    {formatInline(text, `${index}-${lineIdx}`, isUserMsg)}
                                 </span>
                             </div>
                         );
                    }
                    
                    if (line.trim() === '') {
                        // Render empty line
                        return <div key={lineIdx} className="h-2" />;
                    }

                    return (
                        <div key={lineIdx} className="break-words min-w-0">
                            {formatInline(line, `${index}-${lineIdx}`, isUserMsg)}
                        </div>
                    );
                })}
            </div>
        );
    });
  };

  if (isUser) {
    return (
      <div className="flex justify-end items-start gap-3">
        <div className={`${currentPersona.theme.button} rounded-2xl rounded-tr-none p-3 md:p-4 max-w-lg shadow-lg`}>
          <div className="text-white text-sm md:text-base">
              {formatContent(message.content, true)}
          </div>
        </div>
        <div className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center flex-shrink-0 border border-gray-700">
          <UserIcon className="w-6 h-6 text-gray-400" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex justify-start items-start gap-3">
      <div className={`w-10 h-10 rounded-full bg-gradient-to-tr ${currentPersona.theme.avatar} flex items-center justify-center flex-shrink-0 shadow-lg`}>
        <Icon className="w-6 h-6 text-white" />
      </div>
      <div className="bg-gray-800 rounded-2xl rounded-tl-none p-3 md:p-4 max-w-lg shadow-lg border border-gray-700">
        <div className="text-gray-300 text-sm md:text-base">
            {formatContent(message.content, false)}
        </div>
      </div>
    </div>
  );
};
