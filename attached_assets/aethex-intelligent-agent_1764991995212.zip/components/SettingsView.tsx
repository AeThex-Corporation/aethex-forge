
import React, { useState } from 'react';
import { User } from '../types';
import { supabase } from '../services/supabaseClient';

interface SettingsViewProps {
  user: User;
}

const PLANS = [
    { 
        id: 'Free', 
        name: 'Free', 
        price: '$0/mo', 
        features: ['Access to basic personas', 'Standard response speed', 'Community support'] 
    },
    { 
        id: 'Architect', 
        name: 'Architect', 
        price: '$20/mo', 
        features: ['Access to all personas', 'Faster response times', 'Priority support', 'Early access to new features'] 
    },
    { 
        id: 'Council', 
        name: 'Council', 
        price: '$99/mo', 
        features: ['Unlimited access', 'Custom persona creation', 'API Access', 'Governance voting rights', 'Dedicated account manager'] 
    }
];

export const SettingsView: React.FC<SettingsViewProps> = ({ user }) => {
  const [fullName, setFullName] = useState(user.name);
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState<{type: 'success'|'error', text: string} | null>(null);

  // Mock preferences state
  const [emailNotifs, setEmailNotifs] = useState(true);
  const [securityAlerts, setSecurityAlerts] = useState(true);

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setMessage(null);

    try {
      const { error } = await supabase.auth.updateUser({
        data: { full_name: fullName }
      });

      if (error) throw error;
      setMessage({ type: 'success', text: 'Profile updated successfully' });
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message });
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdateTier = async (newTier: string) => {
      setIsLoading(true);
      setMessage(null);
      try {
          // In a real app, this would trigger a payment flow.
          // Here we just update the metadata directly for demonstration.
          const { error } = await supabase.auth.updateUser({
              data: { tier: newTier }
          });
          
          if (error) throw error;
          setMessage({ type: 'success', text: `Plan updated to ${newTier}` });
          
          // Force a session refresh to ensure the UI updates immediately in App.tsx
          await supabase.auth.refreshSession();
          
      } catch (err: any) {
          setMessage({ type: 'error', text: err.message });
      } finally {
          setIsLoading(false);
      }
  };

  return (
    <div className="flex-1 bg-gray-900 text-white overflow-y-auto p-4 md:p-12 animate-fade-in">
      <div className="max-w-4xl mx-auto space-y-12 pb-12">
        <div>
            <h1 className="text-3xl font-bold mb-2">Settings</h1>
            <p className="text-gray-400">Manage your account settings, role, and preferences.</p>
        </div>

        {/* Profile Section */}
        <section className="space-y-6">
            <h2 className="text-xl font-semibold border-b border-gray-800 pb-2">Profile</h2>
            
            <div className="flex items-center gap-6">
                <div className="w-20 h-20 rounded-full bg-gradient-to-br from-cyan-500 to-purple-600 flex items-center justify-center text-2xl font-bold shadow-lg border-2 border-gray-800">
                    {user.name.charAt(0)}
                </div>
                <div>
                    <div className="font-medium text-lg">{user.name}</div>
                    <div className={`text-xs font-bold uppercase tracking-wider px-2 py-1 rounded border inline-block mt-2 ${
                        user.tier === 'Council' ? 'bg-purple-900/30 text-purple-400 border-purple-800' :
                        user.tier === 'Architect' ? 'bg-cyan-900/30 text-cyan-400 border-cyan-800' :
                        'bg-gray-800 text-gray-400 border-gray-700'
                    }`}>
                        {user.tier} Tier
                    </div>
                </div>
            </div>

            <form onSubmit={handleUpdateProfile} className="space-y-6 max-w-md">
                <div className="space-y-1">
                    <label className="block text-sm font-medium text-gray-400">Display Name</label>
                    <input 
                        type="text" 
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2.5 text-white focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500 outline-none transition-all"
                    />
                </div>
                <div className="space-y-1">
                    <label className="block text-sm font-medium text-gray-400">Email Address</label>
                    <input 
                        type="text" 
                        value={user.email}
                        disabled
                        className="w-full bg-gray-800/50 border border-gray-700/50 rounded-lg px-4 py-2.5 text-gray-500 cursor-not-allowed"
                    />
                    <p className="text-xs text-gray-600">Email cannot be changed.</p>
                </div>
                
                {message && (
                    <div className={`text-sm p-3 rounded-lg border ${message.type === 'success' ? 'bg-green-900/20 border-green-800 text-green-400' : 'bg-red-900/20 border-red-800 text-red-400'}`}>
                        {message.text}
                    </div>
                )}

                <button 
                    type="submit"
                    disabled={isLoading || fullName === user.name}
                    className="bg-cyan-600 hover:bg-cyan-500 text-white px-6 py-2.5 rounded-lg text-sm font-medium transition-all shadow-lg shadow-cyan-900/20 disabled:opacity-50 disabled:cursor-not-allowed disabled:shadow-none"
                >
                    {isLoading ? 'Saving...' : 'Save Changes'}
                </button>
            </form>
        </section>

        {/* Subscription Plans */}
        <section className="space-y-6 pt-6 border-t border-gray-800">
            <h2 className="text-xl font-semibold">Subscription & Role</h2>
            <div className="grid md:grid-cols-3 gap-4">
                {PLANS.map(plan => (
                    <div key={plan.id} className={`relative p-6 rounded-xl border flex flex-col ${user.tier === plan.id ? 'bg-gray-800/80 border-cyan-500 ring-1 ring-cyan-500 shadow-lg shadow-cyan-900/10' : 'bg-gray-800/30 border-gray-700 hover:bg-gray-800/50 transition-colors'}`}>
                        {user.tier === plan.id && (
                            <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-cyan-600 text-white text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider shadow-lg">
                                Current Plan
                            </div>
                        )}
                        <div className="mb-4">
                            <h3 className={`text-lg font-bold ${user.tier === plan.id ? 'text-white' : 'text-gray-300'}`}>{plan.name}</h3>
                            <div className="text-2xl font-bold text-white mt-1">{plan.price}</div>
                        </div>
                        <ul className="space-y-3 mb-8 flex-1">
                            {plan.features.map((f, i) => (
                                <li key={i} className="text-sm text-gray-400 flex items-start gap-2">
                                    <span className="text-cyan-500 font-bold mt-0.5">•</span> {f}
                                </li>
                            ))}
                        </ul>
                        <button
                            onClick={() => handleUpdateTier(plan.id)}
                            disabled={isLoading || user.tier === plan.id}
                            className={`w-full py-2.5 rounded-lg text-sm font-bold transition-all ${
                                user.tier === plan.id 
                                    ? 'bg-gray-700 text-gray-500 cursor-default'
                                    : 'bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white shadow-lg shadow-cyan-900/20'
                            }`}
                        >
                            {user.tier === plan.id ? 'Active' : 'Switch Plan'}
                        </button>
                    </div>
                ))}
            </div>
        </section>

        {/* Preferences */}
        <section className="space-y-6 pt-6 border-t border-gray-800">
            <h2 className="text-xl font-semibold">Preferences</h2>
            <div className="space-y-5 max-w-md">
                 <div className="flex items-center justify-between p-4 bg-gray-800/30 rounded-xl border border-gray-800">
                    <div>
                        <div className="font-medium text-gray-200">Product Updates</div>
                        <div className="text-xs text-gray-400 mt-1">Receive news about new features.</div>
                    </div>
                    <button 
                        onClick={() => setEmailNotifs(!emailNotifs)}
                        className={`w-11 h-6 rounded-full transition-colors relative ${emailNotifs ? 'bg-cyan-600' : 'bg-gray-700'}`}
                    >
                        <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-transform shadow-sm ${emailNotifs ? 'left-6' : 'left-1'}`} />
                    </button>
                 </div>

                 <div className="flex items-center justify-between p-4 bg-gray-800/30 rounded-xl border border-gray-800">
                    <div>
                        <div className="font-medium text-gray-200">Security Alerts</div>
                        <div className="text-xs text-gray-400 mt-1">Get notified about suspicious activity.</div>
                    </div>
                    <button 
                        onClick={() => setSecurityAlerts(!securityAlerts)}
                        className={`w-11 h-6 rounded-full transition-colors relative ${securityAlerts ? 'bg-cyan-600' : 'bg-gray-700'}`}
                    >
                        <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-transform shadow-sm ${securityAlerts ? 'left-6' : 'left-1'}`} />
                    </button>
                 </div>
            </div>
        </section>

         {/* Danger Zone */}
         <section className="space-y-6 pt-6 border-t border-gray-800">
             <h2 className="text-xl font-semibold text-red-500">Danger Zone</h2>
             <div className="bg-red-950/10 border border-red-900/30 rounded-xl p-6 flex items-center justify-between">
                <div>
                    <div className="font-medium text-red-200">Delete Account</div>
                    <div className="text-sm text-red-400/60 mt-1">Permanently delete your account and all data.</div>
                </div>
                <button className="text-red-400 bg-red-950/40 hover:bg-red-900/40 border border-red-900/50 px-4 py-2 rounded-lg text-sm font-medium transition-colors">
                    Delete Account
                </button>
             </div>
         </section>
      </div>
    </div>
  );
};
