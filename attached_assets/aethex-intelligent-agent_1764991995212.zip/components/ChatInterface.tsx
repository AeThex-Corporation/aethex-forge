
import React, { useRef, useEffect } from 'react';
import type { ChatMessage as ChatMessageType, Persona } from '../types';
import { ChatMessage } from './ChatMessage';
import { ChatInput } from './ChatInput';
import { TrashIcon } from './Icons';

interface ChatInterfaceProps {
  messages: ChatMessageType[];
  isLoading: boolean;
  onSendMessage: (message: string) => void;
  currentPersona: Persona;
  className?: string;
  onClearChat: () => void;
  isLocked: boolean;
  onUnlock: () => void;
}

export const ChatInterface: React.FC<ChatInterfaceProps> = ({ 
    messages, 
    isLoading, 
    onSendMessage, 
    currentPersona, 
    className,
    onClearChat,
    isLocked,
    onUnlock
}) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(scrollToBottom, [messages]);

  return (
    <div className={`flex flex-col h-full overflow-hidden ${className}`}>
      <main className="flex-1 overflow-y-auto p-4 md:p-8 scrollbar-thin scrollbar-thumb-gray-700 scrollbar-track-transparent">
        <div className="max-w-3xl mx-auto space-y-6 pb-4">
          {messages.map((msg, index) => (
            <ChatMessage key={index} message={msg} currentPersona={currentPersona} />
          ))}
          {isLoading && (
            <div className="flex justify-start animate-fade-in">
                <div className="flex items-center space-x-2">
                    <div className={`w-10 h-10 rounded-full bg-gradient-to-tr ${currentPersona.theme.avatar} flex-shrink-0 opacity-80 flex items-center justify-center shadow-lg`}>
                        <div className="w-2 h-2 bg-white/50 rounded-full animate-ping" />
                    </div>
                    <div className="bg-gray-800/80 rounded-2xl rounded-tl-none p-4 border border-gray-700">
                        <div className="flex items-center justify-center space-x-1">
                            <div className={`w-2 h-2 rounded-full animate-bounce [animation-delay:-0.3s] bg-gray-400`}></div>
                            <div className={`w-2 h-2 rounded-full animate-bounce [animation-delay:-0.15s] bg-gray-400`}></div>
                            <div className={`w-2 h-2 rounded-full animate-bounce bg-gray-400`}></div>
                        </div>
                    </div>
                </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </main>
      <footer className="p-4 md:p-6 bg-gradient-to-t from-gray-900 via-gray-900 to-transparent">
        <div className="max-w-3xl mx-auto">
          <ChatInput 
            onSendMessage={onSendMessage} 
            isLoading={isLoading} 
            currentPersona={currentPersona} 
            isLocked={isLocked}
            onUnlock={onUnlock}
          />
          <div className="flex items-center justify-between mt-2 px-1">
              <p className="text-xs text-gray-600">
                Aethex Agent can make mistakes. Please review critical info.
              </p>
              {!isLoading && !isLocked && messages.length > 1 && (
                  <button 
                    onClick={onClearChat}
                    className="text-xs text-gray-500 hover:text-red-400 transition-colors flex items-center gap-1.5 py-1 px-2 rounded hover:bg-gray-800/50"
                    title="Clear entire conversation"
                  >
                    <TrashIcon className="w-3 h-3" />
                    Clear Chat
                  </button>
              )}
          </div>
        </div>
      </footer>
    </div>
  );
};
