
import React from 'react';
import { AethexLogo, ShieldIcon, HammerIcon, BuildingIcon, BookIcon, ChartIcon, MusicIcon, ScrollIcon, WaveIcon, MoneyIcon, InfoIcon, MenuIcon } from './Icons';
import { Persona, User } from '../types';
import { PERSONAS } from '../constants';

interface HeaderProps {
  currentPersona: Persona;
  onPersonaChange: (persona: Persona) => void;
  onOpenDocs: () => void;
  onToggleSidebar: () => void;
  user: User | null;
}

export const Header: React.FC<HeaderProps> = ({ currentPersona, onPersonaChange, onOpenDocs, onToggleSidebar, user }) => {
  const getIcon = (iconName: string) => {
      switch(iconName) {
          case 'logo': return AethexLogo;
          case 'shield': return ShieldIcon;
          case 'hammer': return HammerIcon;
          case 'building': return BuildingIcon;
          case 'book': return BookIcon;
          case 'chart': return ChartIcon;
          case 'music': return MusicIcon;
          case 'scroll': return ScrollIcon;
          case 'wave': return WaveIcon;
          case 'money': return MoneyIcon;
          default: return AethexLogo;
      }
  };

  const Icon = getIcon(currentPersona.icon);

  // Helper to check if a persona is locked
  const isLocked = (persona: Persona) => {
    const required = persona.requiredTier;
    if (!required || required === 'Free') return false;
    
    const userTier = user?.tier || 'Free';
    
    if (userTier === 'Council') return false;
    if (userTier === 'Architect' && required === 'Architect') return false;
    
    return true;
  };

  return (
    <header className="bg-gray-900 border-b border-gray-800 p-4 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-3">
            <button 
                onClick={onToggleSidebar}
                className="md:hidden p-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded-lg transition-colors"
            >
                <MenuIcon className="w-6 h-6" />
            </button>

            <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg bg-gray-800/50 border border-gray-700 ${currentPersona.theme.primary}`}>
                     <Icon className="w-6 h-6" />
                </div>
                <div>
                    <h1 className={`text-lg font-bold leading-none bg-clip-text text-transparent bg-gradient-to-r ${currentPersona.theme.gradient}`}>
                        {currentPersona.name}
                    </h1>
                    <p className="text-xs text-gray-500 hidden sm:block">{currentPersona.description}</p>
                </div>
            </div>
        </div>
        
        <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center bg-gray-800 rounded-lg p-1 border border-gray-700">
                <span className="text-xs text-gray-400 ml-3 mr-2 font-semibold uppercase tracking-wider">Agent:</span>
                <select 
                    value={currentPersona.id}
                    onChange={(e) => {
                        const selected = PERSONAS.find(p => p.id === e.target.value);
                        if (selected) onPersonaChange(selected);
                    }}
                    className="bg-transparent text-sm text-white border-none outline-none focus:ring-0 cursor-pointer py-1 px-2 rounded hover:bg-gray-700 transition-colors max-w-[150px] sm:max-w-none"
                >
                    {PERSONAS.map(persona => {
                        const locked = isLocked(persona);
                        return (
                            <option key={persona.id} value={persona.id} className="bg-gray-800 text-white">
                                {locked ? '🔒 ' : ''}{persona.name} {locked ? `(${persona.requiredTier})` : ''}
                            </option>
                        );
                    })}
                </select>
            </div>

            {/* Mobile Persona Selector (Simplified) */}
            <select 
                value={currentPersona.id}
                onChange={(e) => {
                    const selected = PERSONAS.find(p => p.id === e.target.value);
                    if (selected) onPersonaChange(selected);
                }}
                className="sm:hidden bg-gray-800 text-white text-sm border border-gray-700 rounded-lg py-2 pl-3 pr-8 focus:ring-1 focus:ring-blue-500 outline-none max-w-[140px]"
            >
                 {PERSONAS.map(persona => {
                    const locked = isLocked(persona);
                    return (
                        <option key={persona.id} value={persona.id} className="bg-gray-800">
                            {locked ? '🔒 ' : ''}{persona.name}
                        </option>
                    );
                 })}
            </select>

            <button
                onClick={onOpenDocs}
                className="p-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded-lg border border-transparent hover:border-gray-700 transition-all"
                title="Documentation"
            >
                <InfoIcon className="w-5 h-5" />
            </button>
        </div>
    </header>
  );
};
