
import React, { useState, useRef } from 'react';
import { SendIcon, PaperclipIcon, ImageIcon, CodeIcon, LockIcon } from './Icons';
import { Persona } from '../types';

interface ChatInputProps {
  onSendMessage: (message: string) => void;
  isLoading: boolean;
  currentPersona: Persona;
  isLocked: boolean;
  onUnlock: () => void;
}

export const ChatInput: React.FC<ChatInputProps> = ({ 
    onSendMessage, 
    isLoading, 
    currentPersona,
    isLocked,
    onUnlock
}) => {
  const [input, setInput] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim() && !isLoading && !isLocked) {
      onSendMessage(input);
      setInput('');
      // Reset height
      if (textareaRef.current) {
          textareaRef.current.style.height = 'auto';
      }
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e as unknown as React.FormEvent);
    }
  };

  const handleAutoResize = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
      const target = e.target;
      target.style.height = 'auto';
      target.style.height = `${Math.min(target.scrollHeight, 200)}px`;
      setInput(target.value);
  };

  const insertMarkdown = (prefix: string, suffix: string, placeholder: string = "") => {
      if (!textareaRef.current) return;
      
      const start = textareaRef.current.selectionStart;
      const end = textareaRef.current.selectionEnd;
      const text = input;
      const selection = text.substring(start, end);
      
      const newText = text.substring(0, start) + prefix + (selection || placeholder) + suffix + text.substring(end);
      
      setInput(newText);
      
      // Reset focus and cursor
      setTimeout(() => {
          textareaRef.current?.focus();
          const newCursorPos = start + prefix.length + (selection || placeholder).length + suffix.length;
          textareaRef.current?.setSelectionRange(newCursorPos, newCursorPos);
      }, 0);
  };

  const insertCodeBlock = () => {
      insertMarkdown("```\n", "\n```", "code");
  };

  if (isLocked) {
    return (
        <div className="bg-gray-800 border border-gray-700 rounded-xl p-6 flex flex-col items-center justify-center text-center shadow-sm">
            <div className="p-3 bg-gray-900 rounded-full mb-3 border border-gray-700">
                <LockIcon className="w-5 h-5 text-gray-400" />
            </div>
            <h3 className="text-white font-medium mb-1">
                {currentPersona.requiredTier} Tier Required
            </h3>
            <p className="text-gray-400 text-sm mb-4 max-w-xs mx-auto">
                This persona is available to {currentPersona.requiredTier} users. Upgrade your account to continue.
            </p>
            <button 
                onClick={onUnlock}
                className="bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white px-6 py-2 rounded-lg text-sm font-bold transition-all shadow-lg shadow-cyan-900/20"
            >
                Upgrade Plan
            </button>
        </div>
    );
  }

  return (
    <div className="bg-gray-800 border border-gray-700 rounded-xl overflow-hidden shadow-sm focus-within:ring-2 focus-within:ring-opacity-50 focus-within:ring-cyan-500 transition-all">
        <form onSubmit={handleSubmit} className="flex flex-col">
            <textarea
                ref={textareaRef}
                value={input}
                onChange={handleAutoResize}
                onKeyDown={handleKeyDown}
                placeholder={`Message ${currentPersona.name}...`}
                className="w-full bg-transparent p-4 text-white placeholder-gray-500 outline-none resize-none"
                style={{ 
                    minHeight: '56px', 
                    maxHeight: '200px',
                }}
                rows={1}
            />
            
            <div className="flex items-center justify-between px-3 py-2 bg-gray-800/50 border-t border-gray-700/50">
                <div className="flex items-center gap-1">
                    <button 
                        type="button"
                        onClick={() => insertMarkdown('[', '](url)', 'File Name')}
                        className="p-2 text-gray-400 hover:text-cyan-400 hover:bg-gray-700/50 rounded-lg transition-colors"
                        title="Attach File (Markdown)"
                    >
                        <PaperclipIcon className="w-5 h-5" />
                    </button>
                    <button 
                        type="button"
                        onClick={() => insertMarkdown('![', '](url)', 'Image Alt')}
                        className="p-2 text-gray-400 hover:text-cyan-400 hover:bg-gray-700/50 rounded-lg transition-colors"
                        title="Upload Image (Markdown)"
                    >
                        <ImageIcon className="w-5 h-5" />
                    </button>
                     <button 
                        type="button"
                        onClick={insertCodeBlock}
                        className="p-2 text-gray-400 hover:text-cyan-400 hover:bg-gray-700/50 rounded-lg transition-colors"
                        title="Insert Code Block"
                    >
                        <CodeIcon className="w-5 h-5" />
                    </button>
                </div>

                <button
                    type="submit"
                    disabled={isLoading || !input.trim()}
                    className={`${currentPersona.theme.button} text-white rounded-lg p-2 transition-all focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed disabled:bg-gray-700`}
                >
                    <SendIcon className="w-5 h-5" />
                </button>
            </div>
        </form>
    </div>
  );
};
