# Aethex Intelligent Agent

A sophisticated web-based intelligent agent interface designed for the Aethex blockchain ecosystem. Powered by Google's Gemini 2.5 AI models, this application provides specialized AI personas to assist users with tasks ranging from on-chain data analysis to game design and ethical auditing.

## Overview

The Aethex Intelligent Agent serves as a "Passport" to a suite of specialized AI tools. Unlike a generic chatbot, this application is built around the concept of **Personas**—specialized agents with unique system instructions, personalities, and capabilities. Some agents have access to external tools (like blockchain data retrieval), while others are strictly analytical or creative.

## Key Features

*   **Multi-Persona Architecture**: Switch seamlessly between 10+ specialized agents, each designed for a specific domain (e.g., coding, music theory, business intelligence).
*   **Function Calling (Tools)**: The "Network Agent" utilizes Gemini's function calling capabilities to retrieve simulated on-chain data, such as wallet balances and transaction details.
*   **Role-Based Access Control (RBAC)**: A tiered permission system (Free, Architect, Council) restricts access to premium agents, encouraging user upgrades.
*   **Rich Text Chat Interface**: Supports Markdown rendering including code blocks, bold/italic text, and lists for complex AI outputs.
*   **Session Management**: Users can maintain multiple active conversation threads, stored locally for persistence.
*   **Authentication & Profiles**: Integrated with Supabase for user accounts, tier management, and profile settings.

## Tech Stack

*   **Frontend**: React 19.2
*   **AI Model**: Google Gemini 2.5 (Flash & Pro) via `@google/genai` SDK
*   **Styling**: Tailwind CSS
*   **Backend Services**: Supabase (Authentication & Database)
*   **Build Tooling**: Vite (inferred environment)

## Available Personas

The application currently supports the following agents:

### Free Tier
*   **Network Agent**: The default assistant. Capable of answering questions about the ecosystem and fetching wallet/token balances.
*   **Ethics Sentinel**: Audits product proposals against the "Axiom AI Ethics Policy" for data sovereignty and safety.

### Architect Tier
*   **Forge Master**: A strict game design consultant that enforces scope reduction ("Ruthless Simplicity").
*   **SBS Architect**: Helps small businesses write compliant profiles for US Government contracting.
*   **Curriculum Weaver**: Converts video game mechanics into K-12 STEM lesson plans.
*   **QuantumLeap**: A Business Intelligence analyst that generates executive summaries from raw data.
*   **Vapor**: A songwriter specialized in Retrowave and Synthwave lyrics.
*   **Apex**: A cynical Venture Capitalist persona that critiques startup ideas.

### Council Tier
*   **Ethos Producer**: Generates technical audio briefs (BPM, Key, Instrumentation) for music composers.
*   **AeThex Archivist**: Generates procedural sci-fi lore and RPG item stats for the "Neon-Grid" universe.

## Setup & Configuration

1.  **Environment Variables**:
    *   `API_KEY`: Required for Google Gemini API access.
2.  **Supabase**:
    *   The client is initialized in `services/supabaseClient.ts`. In a production environment, these keys should be moved to `.env` files.

## Architecture Notes

*   **State Management**: Uses React `useState` and `useEffect` for local state, with `localStorage` for session persistence.
*   **Gemini Integration**: Located in `services/geminiService.ts`. It handles the chat session, history formatting, and tool execution loop (checking for `functionCalls` and sending back `functionResponse`).
*   **Markdown Parsing**: Custom parser in `components/ChatMessage.tsx` handles the rendering of AI responses without heavy external dependencies.
