
import React, { useState, useCallback, useEffect } from 'react';
import { Header } from './components/Header';
import { ChatInterface } from './components/ChatInterface';
import { DocumentationModal } from './components/DocumentationModal';
import { AuthModal } from './components/AuthModal';
import { Sidebar } from './components/Sidebar';
import { SettingsView } from './components/SettingsView';
import { runChat, generateTitle } from './services/geminiService';
import { supabase } from './services/supabaseClient';
import { PERSONAS } from './constants';
import { PlusIcon } from './components/Icons';
import type { ChatMessage, Persona, ChatSession, User } from './types';

const generateId = () => Math.random().toString(36).substring(2, 15);

const App: React.FC = () => {
  // -- State --
  const [sessions, setSessions] = useState<ChatSession[]>(() => {
    try {
        const saved = localStorage.getItem('aethex_sessions');
        return saved ? JSON.parse(saved) : [];
    } catch (e) {
        console.error("Failed to load sessions", e);
        return [];
    }
  });

  const [user, setUser] = useState<User | null>(null);
  
  // Auto-load most recent session on init
  const [activeSessionId, setActiveSessionId] = useState<string | null>(() => {
      try {
          const saved = localStorage.getItem('aethex_sessions');
          if (saved) {
              const parsed: ChatSession[] = JSON.parse(saved);
              if (parsed.length > 0) {
                  // Sort descending by timestamp
                  parsed.sort((a, b) => b.timestamp - a.timestamp);
                  return parsed[0].id;
              }
          }
      } catch (e) {
          // ignore
      }
      return null;
  });

  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isDocsOpen, setIsDocsOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  
  // View state: 'chat' or 'settings'
  const [currentView, setCurrentView] = useState<'chat' | 'settings'>('chat');

  // -- Derived State --
  const activeSession = sessions.find(s => s.id === activeSessionId);
  
  // If no active session, default to first persona. If session exists, find its persona.
  const currentPersonaId = activeSession?.personaId || PERSONAS[0].id;
  const currentPersona = PERSONAS.find(p => p.id === currentPersonaId) || PERSONAS[0];
  
  // Display messages from active session, or empty if none
  const messages = activeSession?.messages || [];

  // -- Effects --
  
  // Save sessions to localStorage
  useEffect(() => {
    localStorage.setItem('aethex_sessions', JSON.stringify(sessions));
  }, [sessions]);

  // Handle Supabase Auth
  useEffect(() => {
    // Check active session on mount
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        setUser({
            id: session.user.id,
            email: session.user.email || '',
            name: session.user.user_metadata.full_name || session.user.email?.split('@')[0] || 'User',
            tier: session.user.user_metadata.tier || 'Free'
        });
      }
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
         setUser({
            id: session.user.id,
            email: session.user.email || '',
            name: session.user.user_metadata.full_name || session.user.email?.split('@')[0] || 'User',
            tier: session.user.user_metadata.tier || 'Free'
        });
        setIsAuthModalOpen(false);
      } else {
        setUser(null);
        setCurrentView('chat'); // Reset view on logout
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  // -- Handlers --

  const handleLogout = async () => {
      await supabase.auth.signOut();
      setUser(null);
  };

  const hasAccess = (requiredTier?: string) => {
      if (!requiredTier || requiredTier === 'Free') return true;
      const userTier = user?.tier || 'Free';
      if (userTier === 'Council') return true;
      if (userTier === 'Architect' && requiredTier === 'Architect') return true;
      return false;
  };

  const handleOpenSettings = () => {
      if (!user) {
          setIsAuthModalOpen(true);
          return;
      }
      setCurrentView('settings');
      setIsSidebarOpen(false);
  };

  const createNewSession = useCallback((personaId: string = PERSONAS[0].id) => {
    const persona = PERSONAS.find(p => p.id === personaId) || PERSONAS[0];

    if (!hasAccess(persona.requiredTier)) {
        handleOpenSettings();
        return;
    }

    const newSession: ChatSession = {
      id: generateId(),
      personaId: persona.id,
      title: 'New Conversation',
      messages: [{ role: 'model', content: persona.initialMessage }],
      timestamp: Date.now()
    };
    
    setSessions(prev => [newSession, ...prev]);
    setActiveSessionId(newSession.id);
    setCurrentView('chat');
    setIsSidebarOpen(false); // Close mobile sidebar on selection
  }, [user]);

  const handleSelectSession = (id: string) => {
    setActiveSessionId(id);
    setCurrentView('chat');
    setIsSidebarOpen(false);
  };

  const handleDeleteSession = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setSessions(prev => prev.filter(s => s.id !== id));
    if (activeSessionId === id) {
      setActiveSessionId(null); 
    }
  };

  const handleClearChat = useCallback(() => {
      if (!activeSessionId) return;

      if (window.confirm("Are you sure you want to clear this conversation? This cannot be undone.")) {
          setSessions(prev => prev.map(s => {
              if (s.id === activeSessionId) {
                  const persona = PERSONAS.find(p => p.id === s.personaId) || PERSONAS[0];
                  return {
                      ...s,
                      messages: [{ role: 'model', content: persona.initialMessage }],
                      timestamp: Date.now()
                  };
              }
              return s;
          }));
      }
  }, [activeSessionId]);

  const handlePersonaChange = (newPersona: Persona) => {
    // Check permissions
    if (!hasAccess(newPersona.requiredTier)) {
        handleOpenSettings();
        return;
    }

    // If we are in settings, switch back to chat first
    if (currentView === 'settings') {
        setCurrentView('chat');
    }

    // If no session is active, create one with this persona
    if (!activeSessionId) {
        createNewSession(newPersona.id);
        return;
    }

    // If active session exists, update it
    const updatedSession = {
        ...activeSession!,
        personaId: newPersona.id,
        messages: [{ role: 'model', content: newPersona.initialMessage } as ChatMessage],
        title: `New ${newPersona.name} Chat`
    };

    setSessions(prev => prev.map(s => s.id === activeSessionId ? updatedSession : s));
  };

  const handleSendMessage = useCallback(async (prompt: string) => {
    if (!prompt.trim() || !activeSessionId) return;

    // Security Check: Ensure user has access to the current persona before engaging model
    if (!hasAccess(currentPersona.requiredTier)) {
        handleOpenSettings();
        return;
    }

    setIsLoading(true);
    
    // 1. Optimistically add user message
    const userMessage: ChatMessage = { role: 'user', content: prompt };
    
    // Check if this is the first user message in the session (length is 1 usually: model greeting)
    const isFirstUserMessage = activeSession && activeSession.messages.length <= 1;

    setSessions(prev => prev.map(session => {
        if (session.id === activeSessionId) {
            // Temporary title logic: truncated prompt
            const tempTitle = isFirstUserMessage 
                ? prompt.slice(0, 30) + (prompt.length > 30 ? '...' : '') 
                : session.title;
            
            return {
                ...session,
                messages: [...session.messages, userMessage],
                title: tempTitle,
                timestamp: Date.now()
            };
        }
        return session;
    }));

    // 2. If it's the first message, generate a better title asynchronously
    if (isFirstUserMessage) {
        generateTitle(prompt).then(aiTitle => {
            setSessions(prev => prev.map(s => 
                s.id === activeSessionId ? { ...s, title: aiTitle } : s
            ));
        }).catch(err => console.error("Failed to generate title", err));
    }

    try {
      const currentHistory = activeSession?.messages || [];
      const fullHistory = [...currentHistory, userMessage];

      const response = await runChat(
        prompt, 
        fullHistory, 
        currentPersona.systemInstruction,
        currentPersona.tools
      );

      const modelMessage: ChatMessage = { role: 'model', content: response };

      // 3. Add model response
      setSessions(prev => prev.map(session => {
        if (session.id === activeSessionId) {
            return {
                ...session,
                messages: [...session.messages, modelMessage],
                timestamp: Date.now()
            };
        }
        return session;
      }));

    } catch (error) {
      console.error("Error communicating with Gemini:", error);
      const errorMessage: ChatMessage = {
        role: 'model',
        content: "Sorry, I encountered an error. Please check the console for details."
      };
      setSessions(prev => prev.map(session => {
        if (session.id === activeSessionId) {
            return {
                ...session,
                messages: [...session.messages, errorMessage]
            };
        }
        return session;
      }));
    } finally {
      setIsLoading(false);
    }
  }, [activeSessionId, activeSession, currentPersona, hasAccess]);

  // Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const isModifier = e.metaKey || e.ctrlKey;
      if (!isModifier) return;

      switch (e.key.toLowerCase()) {
        case 'b': // Toggle Sidebar
            e.preventDefault();
            setIsSidebarOpen(prev => !prev);
            break;
        case 'n': // New Chat
            e.preventDefault();
            createNewSession();
            break;
        case 'k': // Clear Chat
            e.preventDefault();
            if (currentView === 'chat' && activeSessionId) {
                handleClearChat();
            }
            break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeSessionId, currentView, user, isSidebarOpen, createNewSession, handleClearChat]); 

  // Derived check for UI locking
  const hasAccessToCurrentPersona = hasAccess(currentPersona.requiredTier);

  return (
    <div className="flex h-screen bg-gray-900 text-white font-sans overflow-hidden selection:bg-cyan-500/30">
      <Sidebar 
        sessions={sessions}
        activeSessionId={currentView === 'chat' ? activeSessionId : null}
        onSelectSession={handleSelectSession}
        onNewChat={() => createNewSession()}
        onDeleteSession={handleDeleteSession}
        isOpen={isSidebarOpen}
        onCloseMobile={() => setIsSidebarOpen(false)}
        user={user}
        onSignIn={() => setIsAuthModalOpen(true)}
        onSignOut={handleLogout}
        onSettingsClick={handleOpenSettings}
      />
      
      <div className="flex-1 flex flex-col min-w-0 relative transition-all duration-300">
        <Header 
            currentPersona={currentPersona} 
            onPersonaChange={handlePersonaChange} 
            onOpenDocs={() => setIsDocsOpen(true)}
            onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
            user={user}
        />
        
        {currentView === 'settings' && user ? (
            <SettingsView user={user} />
        ) : activeSession ? (
            <ChatInterface
                messages={messages}
                isLoading={isLoading}
                onSendMessage={handleSendMessage}
                currentPersona={currentPersona}
                className="flex-1"
                onClearChat={handleClearChat}
                isLocked={!hasAccessToCurrentPersona}
                onUnlock={handleOpenSettings}
            />
        ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-gray-500 p-6 text-center">
                <div className="bg-gray-800/50 p-6 rounded-2xl border border-gray-700/50 max-w-md w-full shadow-xl">
                    <h2 className="text-xl font-bold text-white mb-2">Welcome to Aethex</h2>
                    <p className="text-sm text-gray-400 mb-6">Start a new conversation to explore the ecosystem, audit ethics, or generate content.</p>
                    <button 
                        onClick={() => createNewSession()}
                        className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white py-3 px-4 rounded-xl transition-colors font-medium"
                    >
                        <PlusIcon className="w-5 h-5" />
                        <span>Start New Chat <span className="ml-2 opacity-60 text-xs font-normal font-mono hidden sm:inline">(Cmd+N)</span></span>
                    </button>
                    <div className="mt-4 text-[10px] text-gray-600 font-mono space-y-1">
                         <p>Cmd+B: Toggle Sidebar</p>
                         <p>Cmd+K: Clear Chat</p>
                    </div>
                </div>
            </div>
        )}
      </div>

      <DocumentationModal 
        isOpen={isDocsOpen} 
        onClose={() => setIsDocsOpen(false)} 
      />

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />
    </div>
  );
};

export default App;
