# AeThex Language Documentation
## aethex.dev

Welcome to the official documentation for the AeThex Programming Language.

**Write once. Build everywhere. Comply by default.**

---

## 📚 Documentation Structure

### Getting Started
- [README.md](README.md) - Complete language overview and features
- [QUICKSTART.md](QUICKSTART.md) - Get up and running in 5 minutes
- [INTEGRATION_SUMMARY.md](INTEGRATION_SUMMARY.md) - OS integration details

### Package Documentation
- [packages/core/README.md](packages/core/README.md) - @aethex.os/core standard library
- [packages/cli/README.md](packages/cli/README.md) - @aethex.os/cli command line interface

### Developer Resources
- [BUILD_SUMMARY.md](BUILD_SUMMARY.md) - Complete build and architecture summary
- [NPM_PUBLISHING_GUIDE.md](NPM_PUBLISHING_GUIDE.md) - Publishing to npm

### Example Code
- [examples/](examples/) - Sample .aethex files

---

## 🚀 Quick Links

### Installation
```bash
npm install -g @aethex.os/cli
```

### npm Packages
- [@aethex.os/cli](https://www.npmjs.com/package/@aethex.os/cli) - Command line compiler
- [@aethex.os/core](https://www.npmjs.com/package/@aethex.os/core) - Standard library

### Community
- **GitHub**: https://github.com/AeThex-Corporation/AeThexOS
- **Issues**: https://github.com/AeThex-Corporation/AeThexOS/issues
- **Website**: https://aethex.app

---

## 📖 Documentation Sections

### 1. Language Guide
Learn the AeThex syntax, from realities and journeys to cross-platform sync.

**Topics covered:**
- Realities (Namespaces)
- Journeys (Functions)
- Cross-Platform Sync
- Conditional Logic
- Platform-Specific Code

### 2. Standard Library
Complete reference for @aethex.os/core utilities.

**Modules:**
- **Passport** - Universal identity across platforms
- **DataSync** - Cross-platform data synchronization
- **SafeInput** - PII detection and scrubbing (CRITICAL for CODEX)
- **Compliance** - COPPA/FERPA compliance checks

### 3. CLI Reference
Command line interface documentation.

**Commands:**
- `aethex compile` - Compile .aethex files
- `aethex new` - Create new project
- `aethex init` - Initialize in current directory

**Targets:**
- JavaScript (Web, Node.js)
- Roblox (Lua)
- UEFN (Verse) - Coming Soon
- Unity (C#) - Coming Soon

### 4. Examples
Real-world code examples and patterns.

**Available Examples:**
- Hello World
- Cross-Platform Authentication
- Secure Leaderboard (Foundry Exam)
- COPPA-Compliant User Registration

---

## 🎓 The Foundry Certification

AeThex is the official language taught at **The AeThex Foundry** certification program.

**Certification Path:**
1. Install AeThex CLI
2. Complete language modules
3. Pass the Foundry exam (build a PII-safe leaderboard)

**Why Learn AeThex?**
- One language, every platform
- Compliance built-in by default
- Industry-recognized certification
- Future-proof for emerging metaverse platforms

---

## 💡 Key Features

### Write Once, Deploy Everywhere
Single .aethex file compiles to JavaScript, Lua, Verse, and C#.

### Compliance by Default
- PII detection automatic
- COPPA age gates built-in
- Audit logging included

### Cross-Platform Sync
```aethex
sync passport across [roblox, uefn, web]
```

One line of code synchronizes data across all platforms.

---

## 🌐 Deployment Guide

### For Documentation Sites
This documentation package is ready to deploy to:
- Static site generators (Jekyll, Hugo, Docusaurus)
- Documentation platforms (GitBook, ReadTheDocs)
- Custom web servers (nginx, Apache)

### Recommended Structure
```
aethex.dev/
├── /              # README.md (landing page)
├── /quickstart    # QUICKSTART.md
├── /guide         # Language guide sections
├── /api           # API reference
├── /examples      # Code examples
└── /cli           # CLI documentation
```

---

## 📝 Contributing

The AeThex Language is open source and welcomes contributions.

**How to Contribute:**
1. Fork the repository
2. Create a feature branch
3. Submit a pull request

---

## 📄 License

MIT License © AeThex Foundation

---

**Built with 🔥 by The AeThex Foundation**

Empowering the next generation of metaverse developers
