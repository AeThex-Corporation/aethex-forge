# Domain Routing Strategy for AeThex OS

This document outlines how different AeThex domains route to specific services and features.

## Domain Service Mapping

### Primary Application (aethex.app)
**Service:** Web Client (React SPA)
**Features:** Full OS interface, dashboard, all features
**Target:** `/dist/public`
**Priority:** Primary entry point

### Corporate & Marketing (aethex.co)
**Service:** Web Client
**Features:** Same as aethex.app
**Target:** `/dist/public`
**Routing:** Can serve different content or redirect to aethex.app

### API Gateway (aethex.network)
**Service:** API Server
**Features:** REST API, WebSocket
**Target:** Express server (port 5000)
**Priority:** Primary API endpoint
**Used by:** Mobile apps, desktop apps, third-party integrations

### Alternative API (aethex.net)
**Service:** API Server
**Features:** Same as aethex.network
**Target:** Express server (port 5000)
**Routing:** CNAME to aethex.network

### API Subdomain (api.aethex.cloud)
**Service:** API Server
**Features:** Same as aethex.network
**Target:** Express server (port 5000)
**Usage:** Alternative API endpoint

### Authentication Hub (aethex.tech)
**Service:** Auth Server
**Features:** OAuth callbacks, password management, SSO
**Target:** Express server (port 5000)
**Priority:** Primary auth domain
**Routes:**
- `/auth/discord/callback`
- `/auth/github/callback`
- `/auth/roblox/callback`
- `/auth/twitch/callback`
- `/auth/minecraft/callback`
- `/upgrade/success` (Stripe)
- `/upgrade/cancel` (Stripe)

### Identity Services (aethex.id)
**Service:** Auth Server
**Features:** Same as aethex.tech
**Target:** Express server (port 5000)
**Routing:** CNAME to aethex.tech or serve identity-focused UI

### Cloud Services (aethex.cloud)
**Service:** Services Server
**Features:** Kernel, Sentinel, Bridge protocols
**Target:** Express server (port 5000)
**Priority:** Primary services endpoint
**Routes:**
- `/api/os/link/*` - Subject linking
- `/api/os/entitlements/*` - Entitlements
- `/api/os/subjects/*` - Subject management

### Kernel (kernel.aethex.cloud)
**Service:** Railway Deployment
**Features:** OS Kernel API
**Target:** Railway (external)
**Priority:** Kernel-specific deployment
**DNS:** CNAME to Railway

### CDN (cdn.aethex.cloud)
**Service:** CDN / Static Assets
**Features:** Cached static files, images, JS, CSS
**Target:** CDN provider or Nginx cache
**Usage:** Static asset delivery

### Education Platform (aethex.education)
**Service:** Web Client
**Features:** Courses, learning modules
**Target:** `/dist/public`
**Routing:** Can serve education-specific SPA build

### Training Platform (aethex.studio)
**Service:** Web Client
**Features:** Foundry bootcamp ($500 training)
**Target:** `/dist/public`
**Priority:** Specialized training portal

### E-commerce (aethex.shop)
**Service:** Web Client + Stripe Integration
**Features:** Marketplace, payments, orders
**Target:** `/dist/public`
**Integrations:** Stripe checkout
**Routes:**
- `/upgrade/success`
- `/upgrade/cancel`
- `/products/*`
- `/checkout/*`

### Support Portal (aethex.support)
**Service:** Web Client
**Features:** Help desk, tickets, knowledge base
**Target:** `/dist/public`
**Integrations:** Support ticket system

### Developer Portal (aethex.dev)
**Service:** Web Client
**Features:** API documentation, SDK downloads, developer guides
**Target:** `/dist/public`
**Content:** Developer-focused content

### Documentation (aethex.info)
**Service:** Web Client
**Features:** General documentation, guides, FAQs
**Target:** `/dist/public`
**Content:** Documentation site

### Blog (aethex.blog)
**Service:** Web Client
**Features:** Blog posts, news, announcements
**Target:** `/dist/public`
**Content:** Blog/CMS integration

### Storage Vault (aethex.locker)
**Service:** Storage Server
**Features:** File upload/download, vault, secure storage
**Target:** Express server (port 5000) + storage backend
**Config:** `client_max_body_size 500M`
**Routes:**
- `/api/storage/upload`
- `/api/storage/download/*`
- `/api/vault/*`

### Bot Services (aethex.bot)
**Service:** API Server
**Features:** Discord bots, AI agents, chatbots
**Target:** Express server (port 5000)
**Routes:**
- `/api/bot/webhook`
- `/api/bot/commands`
- `/api/ai/*`

### Live Streaming (aethex.live)
**Service:** Web Client + WebSocket
**Features:** Live streams, real-time events, broadcasts
**Target:** `/dist/public`
**Integrations:** WebSocket, Twitch API
**Routes:**
- `/stream/*`
- `/live/*`

### Gaming Portal (aethex.fun)
**Service:** Web Client
**Features:** Games, entertainment, Roblox integration
**Target:** `/dist/public`
**Integrations:** Roblox, Minecraft APIs

### Metaverse (aethex.space)
**Service:** Web Client + 3D Engine
**Features:** Virtual worlds, 3D spaces, avatars
**Target:** `/dist/public`
**Tech:** WebGL, Three.js

### User Profiles (aethex.bio)
**Service:** Web Client
**Features:** Public profiles, architect bios
**Target:** `/dist/public`
**Routes:**
- `/:username` - User profile pages
- `/architect/:id` - Architect profiles

### Personal Spaces (aethex.me)
**Service:** Web Client
**Features:** Personal dashboards, private spaces
**Target:** `/dist/public`
**Routes:**
- `/:username` - Personal pages

### Business Solutions (aethex.biz)
**Service:** Web Client
**Features:** Enterprise features, B2B portal
**Target:** `/dist/public`
**Content:** Business-focused features

### Professional Tier (aethex.pro)
**Service:** Web Client
**Features:** Premium features, pro tier
**Target:** `/dist/public`
**Content:** Professional/premium features

### Foundation (aethex.foundation)
**Service:** Web Client
**Features:** Community, grants, foundation info
**Target:** `/dist/public`
**Content:** Foundation-specific content

### Regional - US (aethex.us)
**Service:** Web Client
**Features:** US-specific content, regional services
**Target:** `/dist/public`
**Routing:** Can route to US-specific servers

### Collaboration (aethex.sbs)
**Service:** Web Client
**Features:** Collaboration tools, shared workspaces
**Target:** `/dist/public`
**Features:** Real-time collaboration

### Online Presence (aethex.online)
**Service:** Web Client
**Features:** Same as aethex.app
**Target:** `/dist/public`
**Routing:** CNAME to aethex.app

### Site Builder (aethex.site)
**Service:** Web Client
**Features:** Same as aethex.app
**Target:** `/dist/public`
**Routing:** CNAME to aethex.app

---

## Routing Strategies

### Strategy 1: Single Server, Domain-Based Routing

All domains point to the same server, with nginx handling routing based on domain:

```nginx
# Primary app domains - serve SPA
server_name aethex.app aethex.co aethex.online;
root /var/www/aethex/dist/public;

# API domains - proxy to backend
server_name aethex.network aethex.net;
proxy_pass http://localhost:5000;

# Auth domains - proxy with rate limiting
server_name aethex.tech aethex.id;
limit_req zone=auth_limit;
proxy_pass http://localhost:5000;
```

**Pros:**
- Simple infrastructure
- One server to manage
- Easy to maintain

**Cons:**
- Single point of failure
- All traffic on one server
- Harder to scale individual services

---

### Strategy 2: Multi-Server, Service-Based

Different domains point to different servers:

```
aethex.app, aethex.co → Web Server (SPA)
aethex.network, aethex.net → API Server
aethex.tech, aethex.id → Auth Server
aethex.cloud → Services Server
aethex.locker → Storage Server
```

**Pros:**
- Better isolation
- Can scale services independently
- Security boundaries between services

**Cons:**
- More complex infrastructure
- More servers to manage
- Higher costs

---

### Strategy 3: Hybrid (Recommended)

Core services on dedicated servers, specialized domains as CNAMEs:

```
# Primary servers
aethex.app → Web Server
aethex.network → API Server
aethex.tech → Auth Server
aethex.cloud → Services Server

# CNAMEs to primary
aethex.co → CNAME to aethex.app
aethex.net → CNAME to aethex.network
aethex.id → CNAME to aethex.tech
aethex.education → CNAME to aethex.app
aethex.studio → CNAME to aethex.app
# ... etc
```

**Pros:**
- Balance of simplicity and separation
- Easy to migrate to dedicated servers later
- Cost-effective

**Cons:**
- Some domains share resources
- Still need nginx routing logic

---

## Domain-to-Feature Mapping

### Content Detection

The application can detect which domain it's running on and show appropriate content:

```typescript
// client/src/lib/domain-routing.ts
export function getCurrentDomain(): string {
  return window.location.hostname;
}

export function getDomainFeatures(domain: string): string[] {
  const featureMap = {
    'aethex.app': ['web', 'os', 'auth', 'all'],
    'aethex.education': ['web', 'learning', 'courses'],
    'aethex.studio': ['web', 'training', 'bootcamp'],
    'aethex.shop': ['web', 'commerce', 'stripe'],
    'aethex.dev': ['web', 'docs', 'api'],
    'aethex.fun': ['web', 'gaming', 'roblox'],
    'aethex.live': ['web', 'streaming', 'twitch'],
    // ... etc
  };

  return featureMap[domain] || ['web'];
}

export function shouldShowFeature(feature: string): boolean {
  const domain = getCurrentDomain();
  const features = getDomainFeatures(domain);
  return features.includes(feature) || features.includes('all');
}
```

Usage in components:

```tsx
import { shouldShowFeature } from '@/lib/domain-routing';

export function Dashboard() {
  return (
    <div>
      {shouldShowFeature('courses') && <CoursesSection />}
      {shouldShowFeature('commerce') && <ShopSection />}
      {shouldShowFeature('gaming') && <GamesSection />}
    </div>
  );
}
```

---

## URL Structure Guidelines

### aethex.app (Main Application)
```
https://aethex.app/
https://aethex.app/dashboard
https://aethex.app/profile
https://aethex.app/settings
```

### aethex.education (Education)
```
https://aethex.education/
https://aethex.education/courses
https://aethex.education/course/:id
https://aethex.education/progress
```

### aethex.studio (Training)
```
https://aethex.studio/
https://aethex.studio/foundry
https://aethex.studio/bootcamp
https://aethex.studio/enroll
```

### aethex.shop (E-commerce)
```
https://aethex.shop/
https://aethex.shop/products
https://aethex.shop/product/:id
https://aethex.shop/checkout
https://aethex.shop/upgrade/success
```

### aethex.dev (Developer)
```
https://aethex.dev/
https://aethex.dev/docs
https://aethex.dev/api-reference
https://aethex.dev/sdk
```

### aethex.bio (Profiles)
```
https://aethex.bio/:username
https://aethex.bio/architect/:id
```

---

## Next Steps

1. Choose routing strategy (recommend Hybrid)
2. Implement `domain-routing.ts` for feature detection
3. Update components to use `shouldShowFeature()`
4. Configure nginx based on chosen strategy
5. Test domain-specific features
6. Deploy and monitor

For deployment instructions, see `/DOMAIN_SETUP_GUIDE.md`.
