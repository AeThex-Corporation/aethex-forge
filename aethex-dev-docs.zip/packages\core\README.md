# @aethex.os/core

AeThex Language Standard Library - Cross-platform utilities for authentication, data sync, and compliance.

## Installation

```bash
npm install @aethex.os/core
```

## Features

- **Passport** - Universal identity across platforms
- **DataSync** - Cross-platform data synchronization
- **SafeInput** - PII detection and scrubbing (CRITICAL for CODEX)
- **Compliance** - COPPA/FERPA compliance checks

## Usage

### Passport - Universal Identity

```javascript
const { Passport } = require('@aethex/core');

const passport = new Passport('user123', 'PlayerOne');
await passport.verify();
await passport.syncAcross(['roblox', 'web']);
```

### SafeInput - PII Detection

```javascript
const { SafeInput } = require('@aethex/core');

// Detect PII
const detected = SafeInput.detectPII('Call me at 555-1234');
// Returns: ['phone']

// Scrub PII
const clean = SafeInput.scrub('My email is user@example.com');
// Returns: 'My email is [EMAIL_REDACTED]'

// Validate input
const result = SafeInput.validate('PlayerName123');
if (result.valid) {
  console.log('Safe to use');
}
```

### Compliance - COPPA Checks

```javascript
const { Compliance } = require('@aethex/core');

// Age gate
if (Compliance.isCOPPACompliant(userAge)) {
  // User is 13+
}

// Log compliance check
Compliance.logCheck(userId, 'leaderboard_submission', true);
```

## API Reference

### Passport

- `new Passport(userId, username)` - Create passport
- `verify()` - Verify identity
- `syncAcross(platforms)` - Sync across platforms
- `toJSON()` - Export as JSON

### DataSync

- `DataSync.sync(data, platforms)` - Sync data
- `DataSync.pull(userId, platform)` - Pull data

### SafeInput

- `SafeInput.detectPII(input)` - Returns array of detected PII types
- `SafeInput.scrub(input)` - Returns scrubbed string
- `SafeInput.validate(input, allowedTypes?)` - Returns validation result

### Compliance

- `Compliance.isCOPPACompliant(age)` - Check if 13+
- `Compliance.requiresParentConsent(age)` - Check if <13
- `Compliance.canCollectData(user)` - Check data collection permission
- `Compliance.logCheck(userId, checkType, result)` - Log audit trail

## License

MIT © AeThex Foundation

## Links

- [Documentation](https://aethex.dev/lang)
- [GitHub](https://github.com/aethex/aethex-lang)
- [Issues](https://github.com/aethex/aethex-lang/issues)
