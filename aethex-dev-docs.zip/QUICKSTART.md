# AeThex Language - Quick Start Guide

Get up and running with AeThex in 5 minutes.

## Installation

```bash
# Install the CLI globally
npm install -g @aethex.os/cli

# Verify installation
aethex --version
```

## Your First AeThex Program

### Step 1: Create a new project

```bash
aethex new my-first-game
cd my-first-game
npm install
```

### Step 2: Edit `src/main.aethex`

```aethex
reality MyFirstGame {
    platforms: [roblox, web]
}

journey WelcomePlayer(username) {
    platform: all
    notify "Welcome, " + username + "!"
}
```

### Step 3: Compile and run

```bash
# Compile to JavaScript
npm run build

# Run it
node build/main.js

# Or compile to Roblox
npm run build:roblox
```

## Example Projects

### 1. Cross-Platform Authentication

```aethex
import { Passport } from "@aethex.os/core"

journey Login(username) {
    let passport = new Passport(username)
    
    when passport.verify() {
        sync passport across [roblox, web]
        notify "Logged in everywhere!"
    }
}
```

Compile and run:
```bash
aethex compile auth.aethex
node auth.js
```

### 2. PII-Safe Leaderboard (Foundry Exam)

```aethex
import { SafeInput } from "@aethex.os/core"

journey SubmitScore(player, score) {
    let validation = SafeInput.validate(score)
    
    when validation.valid {
        # Safe to submit
        notify "Score: " + score
    } otherwise {
        # PII detected!
        notify "Error: " + validation.message
    }
}
```

This is the Foundry certification exam - if you can build this correctly, you're ready to work in metaverse development.

## VS Code Setup

1. Install the AeThex extension:
   - Open VS Code
   - Go to Extensions (Ctrl+Shift+X)
   - Search for "AeThex Language Support"
   - Install it

2. Open any `.aethex` file

3. Press **Ctrl+Shift+B** to compile

## Compilation Targets

```bash
# JavaScript (default)
aethex compile game.aethex

# Roblox (Lua)
aethex compile game.aethex --target roblox --output game.lua

# UEFN (Verse) - Coming soon
aethex compile game.aethex --target uefn --output game.verse

# Unity (C#) - Coming soon
aethex compile game.aethex --target unity --output game.cs
```

## Watch Mode

Auto-recompile on file save:

```bash
aethex compile game.aethex --watch
```

## Project Structure

```
my-project/
├── aethex.config.json    # Config file
├── package.json           # npm dependencies
├── src/
│   ├── main.aethex       # Your code
│   ├── auth.aethex
│   └── game.aethex
└── build/
    ├── main.js           # Compiled JavaScript
    └── main.lua          # Compiled Lua
```

## Standard Library

```aethex
# Import from @aethex.os/core
import { Passport, DataSync, SafeInput, Compliance } from "@aethex.os/core"

# Import from @aethex.os/roblox
import { RemoteEvent, Leaderboard } from "@aethex.os/roblox"
```

## Common Patterns

### Authentication

```aethex
journey Login(user) {
    when user.verify() {
        sync user.passport across [roblox, web]
    }
}
```

### Data Sync

```aethex
journey SaveProgress(player) {
    sync player.stats across [roblox, uefn, web]
}
```

### PII Protection

```aethex
let result = SafeInput.validate(userInput)
when result.valid {
    # Safe to use
}
```

### COPPA Compliance

```aethex
when Compliance.isCOPPACompliant(user.age) {
    # User is 13+
}
```

## Next Steps

1. **Read the full docs:** https://aethex.dev/lang
2. **Try the examples:** `/examples` folder
3. **Join The Foundry:** https://aethex.foundation
4. **Contribute:** https://github.com/aethex/aethex-lang

## Getting Help

- **GitHub Issues:** https://github.com/aethex/aethex-lang/issues
- **Discord:** https://discord.gg/aethex
- **Email:** support@aethex.dev

---

**Welcome to the future of metaverse development!** 🚀
