# @aethex.os/cli

AeThex Language Command Line Interface - Compile `.aethex` files to JavaScript, Lua, Verse, and C#.

## Installation

```bash
npm install -g @aethex.os/cli
```

## Usage

### Compile a file

```bash
aethex compile myfile.aethex
```

### Compile to specific target

```bash
# JavaScript (default)
aethex compile myfile.aethex --target javascript

# Roblox/Lua
aethex compile myfile.aethex --target roblox

# UEFN/Verse (coming soon)
aethex compile myfile.aethex --target uefn

# Unity/C# (coming soon)
aethex compile myfile.aethex --target unity
```

### Save to file

```bash
aethex compile myfile.aethex -o output.js
aethex compile myfile.aethex -t roblox -o game.lua
```

### Watch mode

```bash
aethex compile myfile.aethex --watch
```

### Create new project

```bash
# Basic project
aethex new my-project

# With template
aethex new my-game --template passport
```

### Initialize in existing directory

```bash
aethex init
```

## Example

Create `hello.aethex`:

```aethex
reality HelloWorld {
    platforms: all
}

journey Greet(name) {
    platform: all
    notify "Hello, " + name + "!"
}
```

Compile it:

```bash
aethex compile hello.aethex -o hello.js
```

Run it:

```bash
node hello.js
```

## Commands

- `aethex compile <file>` - Compile an AeThex file
- `aethex new <name>` - Create new project
- `aethex init` - Initialize in current directory
- `aethex --help` - Show help
- `aethex --version` - Show version

## Options

- `-t, --target <platform>` - Target platform (javascript, roblox, uefn, unity)
- `-o, --output <file>` - Output file path
- `-w, --watch` - Watch for changes
- `--template <type>` - Project template (basic, passport, game)

## Targets

| Target | Language | Platform | Status |
|--------|----------|----------|--------|
| `javascript` | JavaScript | Web, Node.js | ✅ Ready |
| `roblox` | Lua | Roblox | ✅ Ready |
| `uefn` | Verse | Fortnite | 🚧 Coming Soon |
| `unity` | C# | Unity, VRChat | 🚧 Coming Soon |

## Learn More

- [Language Guide](https://aethex.dev/lang)
- [Examples](https://github.com/aethex/aethex-lang/tree/main/examples)
- [Standard Library (@aethex.os/core)](https://www.npmjs.com/package/@aethex.os/core)

## License

MIT © AeThex Foundation

## Links

- [Documentation](https://aethex.dev/lang)
- [GitHub](https://github.com/aethex/aethex-lang)
- [Issues](https://github.com/aethex/aethex-lang/issues)
