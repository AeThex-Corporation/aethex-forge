# AeThex Domain Integration Guide

This guide covers how to connect all 29+ AeThex domains to the OS infrastructure.

## Table of Contents
1. [DNS Configuration](#dns-configuration)
2. [SSL/TLS Certificates](#ssltls-certificates)
3. [Reverse Proxy Setup](#reverse-proxy-setup)
4. [Application Configuration](#application-configuration)
5. [Deployment Strategy](#deployment-strategy)

---

## DNS Configuration

### Primary Domains (Active Services)

Configure these DNS records at your domain registrar:

#### Web Application Domains
```dns
# Main OS Interface
aethex.app          A      <your-web-server-ip>
aethex.app          AAAA   <your-web-server-ipv6>

# Alternative entry points
aethex.co           CNAME  aethex.app
aethex.online       CNAME  aethex.app
aethex.site         CNAME  aethex.app
```

#### API & Network Services
```dns
# Primary API
aethex.network      A      <your-api-server-ip>
aethex.net          CNAME  aethex.network

# API Gateway
api.aethex.cloud    A      <your-api-server-ip>
```

#### Authentication Services
```dns
# Primary Auth
aethex.tech         A      <your-auth-server-ip>
aethex.id           CNAME  aethex.tech
```

#### Cloud Services & Kernel
```dns
# Services Layer
aethex.cloud        A      <your-services-server-ip>

# Kernel (Railway deployment)
kernel.aethex.cloud CNAME  <your-railway-url>.up.railway.app

# CDN
cdn.aethex.cloud    CNAME  <your-cdn-provider>
```

#### Specialized Services
```dns
# Education & Training
aethex.education    CNAME  aethex.app
aethex.studio       CNAME  aethex.app

# E-commerce
aethex.shop         CNAME  aethex.app

# Support
aethex.support      CNAME  aethex.app

# Documentation
aethex.dev          CNAME  aethex.app
aethex.info         CNAME  aethex.app

# Blog & Content
aethex.blog         CNAME  aethex.app

# Storage
aethex.locker       A      <your-storage-server-ip>

# Bot Services
aethex.bot          A      <your-api-server-ip>

# Live Streaming
aethex.live         CNAME  aethex.app

# Gaming
aethex.fun          CNAME  aethex.app

# Metaverse
aethex.space        CNAME  aethex.app

# Profiles
aethex.bio          CNAME  aethex.app
aethex.me           CNAME  aethex.app

# Business
aethex.biz          CNAME  aethex.app
aethex.pro          CNAME  aethex.app

# Foundation
aethex.foundation   CNAME  aethex.app

# Regional
aethex.us           CNAME  aethex.app

# Collaboration
aethex.sbs          CNAME  aethex.app

# Waitlist
waitlist.aethex.app A      <your-web-server-ip>
```

### DNS Propagation Check

After configuring DNS, verify propagation:

```bash
# Check A records
dig aethex.app +short
dig aethex.network +short

# Check CNAME records
dig aethex.tech +short
dig kernel.aethex.cloud +short

# Check from multiple locations
for domain in aethex.app aethex.network aethex.tech aethex.cloud; do
  echo "Checking $domain..."
  dig $domain +short @8.8.8.8
  dig $domain +short @1.1.1.1
done
```

---

## SSL/TLS Certificates

### Option 1: Let's Encrypt with Certbot (Recommended)

Install certbot and obtain certificates for all domains:

```bash
# Install certbot
sudo apt-get update
sudo apt-get install certbot python3-certbot-nginx

# Obtain certificates (batch request)
sudo certbot certonly --nginx \
  -d aethex.app \
  -d aethex.co \
  -d aethex.network \
  -d aethex.net \
  -d aethex.tech \
  -d aethex.id \
  -d aethex.cloud \
  -d kernel.aethex.cloud \
  -d api.aethex.cloud \
  -d cdn.aethex.cloud \
  -d aethex.education \
  -d aethex.studio \
  -d aethex.shop \
  -d aethex.support \
  -d aethex.dev \
  -d aethex.info \
  -d aethex.blog \
  -d aethex.locker \
  -d aethex.bot \
  -d aethex.live \
  -d aethex.fun \
  -d aethex.space \
  -d aethex.bio \
  -d aethex.me \
  -d aethex.biz \
  -d aethex.pro \
  -d aethex.foundation \
  -d aethex.us \
  -d aethex.sbs \
  -d aethex.online \
  -d aethex.site \
  --email admin@aethex.app \
  --agree-tos

# Auto-renewal (certbot creates this automatically)
sudo systemctl enable certbot.timer
sudo systemctl start certbot.timer
```

### Option 2: Cloudflare (Free SSL + CDN)

1. Add all domains to Cloudflare
2. Update nameservers at your registrar
3. Enable "Full (strict)" SSL mode
4. Enable "Always Use HTTPS"
5. Configure Page Rules for routing

### Option 3: Wildcard Certificate

For subdomains like `*.aethex.cloud`:

```bash
sudo certbot certonly --manual \
  --preferred-challenges dns \
  -d *.aethex.cloud \
  -d aethex.cloud
```

Follow prompts to add TXT records to DNS.

---

## Reverse Proxy Setup

### Nginx Configuration

Create `/etc/nginx/sites-available/aethex-domains`:

```nginx
# Web Application Domains (React SPA)
server {
    listen 80;
    listen [::]:80;
    server_name aethex.app aethex.co aethex.online aethex.site
                aethex.education aethex.studio aethex.shop aethex.support
                aethex.dev aethex.info aethex.blog aethex.fun aethex.space
                aethex.bio aethex.me aethex.biz aethex.pro aethex.foundation
                aethex.us aethex.sbs aethex.live;

    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name aethex.app aethex.co aethex.online aethex.site
                aethex.education aethex.studio aethex.shop aethex.support
                aethex.dev aethex.info aethex.blog aethex.fun aethex.space
                aethex.bio aethex.me aethex.biz aethex.pro aethex.foundation
                aethex.us aethex.sbs aethex.live;

    ssl_certificate /etc/letsencrypt/live/aethex.app/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/aethex.app/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;

    root /var/www/aethex/dist/public;
    index index.html;

    # SPA routing
    location / {
        try_files $uri $uri/ /index.html;
    }

    # API proxy to backend
    location /api/ {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    # WebSocket support
    location /ws {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "Upgrade";
        proxy_set_header Host $host;
    }

    # Static assets caching
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}

# API & Network Services
server {
    listen 80;
    listen [::]:80;
    server_name aethex.network aethex.net api.aethex.cloud;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name aethex.network aethex.net api.aethex.cloud;

    ssl_certificate /etc/letsencrypt/live/aethex.network/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/aethex.network/privkey.pem;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Rate limiting for API
    limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
    limit_req zone=api burst=20;
}

# Authentication Services
server {
    listen 80;
    listen [::]:80;
    server_name aethex.tech aethex.id;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name aethex.tech aethex.id;

    ssl_certificate /etc/letsencrypt/live/aethex.tech/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/aethex.tech/privkey.pem;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}

# Cloud Services
server {
    listen 80;
    listen [::]:80;
    server_name aethex.cloud;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name aethex.cloud;

    ssl_certificate /etc/letsencrypt/live/aethex.cloud/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/aethex.cloud/privkey.pem;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}

# Bot Services
server {
    listen 80;
    listen [::]:80;
    server_name aethex.bot;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name aethex.bot;

    ssl_certificate /etc/letsencrypt/live/aethex.bot/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/aethex.bot/privkey.pem;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}

# Storage Services
server {
    listen 80;
    listen [::]:80;
    server_name aethex.locker;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name aethex.locker;

    ssl_certificate /etc/letsencrypt/live/aethex.locker/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/aethex.locker/privkey.pem;

    client_max_body_size 100M;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

Enable the configuration:

```bash
# Link configuration
sudo ln -s /etc/nginx/sites-available/aethex-domains /etc/nginx/sites-enabled/

# Test configuration
sudo nginx -t

# Reload nginx
sudo systemctl reload nginx
```

---

## Application Configuration

### Update Environment Variables

Create/update `.env.production`:

```bash
# Node Environment
NODE_ENV=production

# Domain Configuration
PRIMARY_DOMAIN=aethex.app
API_DOMAIN=aethex.network
AUTH_DOMAIN=aethex.tech
CLOUD_DOMAIN=aethex.cloud

# Allowed Origins (all domains)
ALLOWED_ORIGINS=https://aethex.app,https://aethex.co,https://aethex.network,https://aethex.net,https://aethex.tech,https://aethex.id,https://aethex.cloud,https://kernel.aethex.cloud,https://api.aethex.cloud,https://aethex.education,https://aethex.studio,https://aethex.shop,https://aethex.support,https://aethex.dev,https://aethex.info,https://aethex.blog,https://aethex.locker,https://aethex.bot,https://aethex.live,https://aethex.fun,https://aethex.space,https://aethex.bio,https://aethex.me,https://aethex.biz,https://aethex.pro,https://aethex.foundation,https://aethex.us,https://aethex.sbs,https://aethex.online,https://aethex.site

# API Configuration
VITE_API_BASE_URL=https://aethex.network

# Supabase
SUPABASE_URL=https://kmdeisowhtsalsekkzqd.supabase.co
SUPABASE_SERVICE_KEY=<your-service-key>
VITE_SUPABASE_URL=https://kmdeisowhtsalsekkzqd.supabase.co
VITE_SUPABASE_ANON_KEY=<your-anon-key>

# OAuth Providers
OAUTH_REDIRECT_URI=https://aethex.app
DISCORD_CLIENT_ID=<your-client-id>
DISCORD_CLIENT_SECRET=<your-client-secret>
GITHUB_CLIENT_ID=<your-client-id>
GITHUB_CLIENT_SECRET=<your-client-secret>
ROBLOX_CLIENT_ID=<your-client-id>
ROBLOX_CLIENT_SECRET=<your-client-secret>
TWITCH_CLIENT_ID=<your-client-id>
TWITCH_CLIENT_SECRET=<your-client-secret>

# Stripe
STRIPE_SECRET_KEY=<your-stripe-key>
STRIPE_SUCCESS_URL=https://aethex.tech/upgrade/success
STRIPE_CANCEL_URL=https://aethex.tech/upgrade/cancel

# Session
SESSION_SECRET=<generate-strong-secret-32chars>

# Database
DATABASE_URL=postgresql://user:password@host:5432/aethex_os
```

### Update CORS Configuration

Update `server/index.ts` or create `server/cors-config.ts`:

```typescript
import cors from 'cors';

// All AeThex domains
const allowedOrigins = [
  'https://aethex.app',
  'https://aethex.co',
  'https://aethex.network',
  'https://aethex.net',
  'https://aethex.tech',
  'https://aethex.id',
  'https://aethex.cloud',
  'https://kernel.aethex.cloud',
  'https://api.aethex.cloud',
  'https://cdn.aethex.cloud',
  'https://aethex.education',
  'https://aethex.studio',
  'https://aethex.shop',
  'https://aethex.support',
  'https://aethex.dev',
  'https://aethex.info',
  'https://aethex.blog',
  'https://aethex.locker',
  'https://aethex.bot',
  'https://aethex.live',
  'https://aethex.fun',
  'https://aethex.space',
  'https://aethex.bio',
  'https://aethex.me',
  'https://aethex.biz',
  'https://aethex.pro',
  'https://aethex.foundation',
  'https://aethex.us',
  'https://aethex.sbs',
  'https://aethex.online',
  'https://aethex.site',
  // Development
  'http://localhost:5173',
  'http://localhost:5000',
];

export const corsOptions: cors.CorsOptions = {
  origin: (origin, callback) => {
    // Allow requests with no origin (mobile apps, Postman, etc.)
    if (!origin) return callback(null, true);

    if (allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
};
```

### Update OAuth Redirect URIs

For each OAuth provider, add ALL possible redirect URIs:

**Discord Developer Portal:**
```
https://aethex.app/auth/discord/callback
https://aethex.tech/auth/discord/callback
https://aethex.id/auth/discord/callback
```

**GitHub OAuth Apps:**
```
https://aethex.app/auth/github/callback
https://aethex.tech/auth/github/callback
https://aethex.dev/auth/github/callback
```

**Roblox Creator Hub:**
```
https://aethex.app/auth/roblox/callback
https://aethex.tech/auth/roblox/callback
https://aethex.fun/auth/roblox/callback
```

**Twitch Developer Console:**
```
https://aethex.app/auth/twitch/callback
https://aethex.tech/auth/twitch/callback
https://aethex.live/auth/twitch/callback
```

**Microsoft Azure (Minecraft):**
```
https://aethex.app/auth/minecraft/callback
https://aethex.tech/auth/minecraft/callback
https://aethex.fun/auth/minecraft/callback
```

---

## Deployment Strategy

### Phase 1: Core Infrastructure (Week 1)

1. **Primary Domains:**
   - aethex.app (main application)
   - aethex.network (API)
   - aethex.tech (auth)
   - aethex.cloud (services)
   - kernel.aethex.cloud (Railway deployment)

2. **Setup:**
   - Configure DNS for primary domains
   - Obtain SSL certificates
   - Deploy nginx configuration
   - Test OAuth flows
   - Verify API connectivity

### Phase 2: Content & Services (Week 2)

1. **Content Domains:**
   - aethex.education
   - aethex.studio
   - aethex.blog
   - aethex.info
   - aethex.dev

2. **Service Domains:**
   - aethex.bot
   - aethex.locker
   - aethex.shop

3. **Setup:**
   - Route to appropriate services
   - Configure content delivery
   - Test e-commerce integration

### Phase 3: Community & Specialized (Week 3)

1. **Community Domains:**
   - aethex.live
   - aethex.space
   - aethex.fun
   - aethex.bio
   - aethex.me

2. **Setup:**
   - Configure specialized features
   - Test streaming capabilities
   - Verify profile systems

### Phase 4: Regional & Business (Week 4)

1. **Business Domains:**
   - aethex.biz
   - aethex.pro
   - aethex.foundation
   - aethex.support

2. **Regional:**
   - aethex.us

3. **Setup:**
   - Configure support systems
   - Test enterprise features
   - Regional routing if needed

### Phase 5: Custom TLD (.aethex via Freename)

1. **Blockchain DNS Setup:**
   - Configure Freename nameservers
   - Create architect subdomains
   - Integrate with Web3 wallets

2. **Examples:**
   - `architect.aethex`
   - `kernel.aethex`
   - `os.aethex`

---

## Monitoring & Verification

### Health Check Endpoints

Test each domain:

```bash
# Create test script
cat > test-domains.sh << 'EOF'
#!/bin/bash

DOMAINS=(
  "aethex.app"
  "aethex.co"
  "aethex.network"
  "aethex.tech"
  "aethex.cloud"
  "kernel.aethex.cloud"
  "aethex.education"
  "aethex.studio"
  "aethex.shop"
  "aethex.bot"
  "aethex.locker"
  "aethex.live"
  "aethex.dev"
  "aethex.info"
  "aethex.blog"
  "aethex.fun"
  "aethex.space"
  "aethex.bio"
  "aethex.me"
  "aethex.biz"
  "aethex.pro"
  "aethex.foundation"
  "aethex.us"
  "aethex.support"
  "aethex.sbs"
  "aethex.online"
  "aethex.site"
  "aethex.id"
  "aethex.net"
)

for domain in "${DOMAINS[@]}"; do
  echo -n "Testing https://$domain ... "
  status=$(curl -s -o /dev/null -w "%{http_code}" "https://$domain" --max-time 5)
  if [ "$status" -eq 200 ] || [ "$status" -eq 301 ] || [ "$status" -eq 302 ]; then
    echo "✓ $status"
  else
    echo "✗ $status"
  fi
done
EOF

chmod +x test-domains.sh
./test-domains.sh
```

### SSL Certificate Monitoring

```bash
# Check certificate expiry
for domain in aethex.app aethex.network aethex.tech aethex.cloud; do
  echo "Checking $domain..."
  echo | openssl s_client -servername $domain -connect $domain:443 2>/dev/null | openssl x509 -noout -dates
done
```

### Uptime Monitoring

Set up monitoring with:
- UptimeRobot (free for 50 monitors)
- Pingdom
- StatusCake
- Custom monitoring with `/health` endpoints

---

## Troubleshooting

### DNS Not Resolving

```bash
# Clear local DNS cache
sudo systemd-resolve --flush-caches  # Linux
dscacheutil -flushcache              # macOS

# Check DNS propagation
dig aethex.app @8.8.8.8
dig aethex.app @1.1.1.1
```

### SSL Certificate Issues

```bash
# Renew certificates manually
sudo certbot renew --force-renewal

# Check certificate chain
openssl s_client -connect aethex.app:443 -showcerts
```

### CORS Errors

Check:
1. Origin is in `allowedOrigins` array
2. Credentials are set correctly
3. Preflight OPTIONS requests succeed

### OAuth Redirect Mismatch

Ensure redirect URI matches exactly:
- Protocol (https)
- Domain (including subdomain)
- Path (including trailing slash if configured)

---

## Next Steps

1. Review `config/domains.json` for domain-to-service mapping
2. Configure DNS records at your registrar
3. Obtain SSL certificates
4. Deploy nginx configuration
5. Update application environment variables
6. Test OAuth flows on each domain
7. Monitor health checks

For Railway deployment of `kernel.aethex.cloud`, see `/RAILWAY_DEPLOYMENT.md`.
