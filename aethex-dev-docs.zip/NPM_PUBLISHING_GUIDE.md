# AeThex Language - NPM Publishing Guide

This guide covers how to publish the AeThex Language packages to npm.

## Package Structure

```
aethex-lang/
├── packages/
│   ├── core/              # @aethex.os/core
│   │   ├── package.json
│   │   ├── index.js       # Passport, DataSync, SafeInput, Compliance
│   │   └── index.d.ts     # TypeScript definitions
│   │
│   └── cli/               # @aethex.os/cli
│       ├── package.json
│       ├── bin/
│       │   └── aethex.js  # CLI entry point
│       └── lib/
│           └── compiler.js # Compiler implementation
```

## Prerequisites

1. **npm Account**
   ```bash
   npm login
   ```

2. **Organization Setup**
   - Create `@aethex.os` organization on npmjs.com
   - Invite team members

## Publishing Steps

### 1. Prepare Packages

#### Core Package

```bash
cd packages/core

# Copy the runtime
cp ../../core.js ./index.js

# Create TypeScript definitions
cat > index.d.ts << 'EOF'
export class Passport {
  userId: string;
  username: string;
  platforms: string[];
  verified: boolean;
  constructor(userId: string, username: string);
  verify(): Promise<boolean>;
  syncAcross(platforms: string[]): Promise<boolean>;
  toJSON(): object;
}

export class DataSync {
  static sync(data: any, platforms: string[]): Promise<boolean>;
  static pull(userId: string, platform: string): Promise<any>;
}

export class SafeInput {
  static detectPII(input: string): string[];
  static scrub(input: string): string;
  static validate(input: string, allowedTypes?: string[]): {
    valid: boolean;
    clean?: string;
    blocked?: string[];
    message?: string;
  };
}

export class Compliance {
  static isCOPPACompliant(age: number): boolean;
  static requiresParentConsent(age: number): boolean;
  static canCollectData(user: { age: number; parentConsentGiven?: boolean }): boolean;
  static logCheck(userId: string, checkType: string, result: boolean): void;
}
EOF

# Create README
cp ../../README.md ./README.md

# Create LICENSE
cat > LICENSE << 'EOF'
MIT License

Copyright (c) 2026 AeThex Foundation

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
EOF
```

#### CLI Package

```bash
cd ../cli

# Create bin directory
mkdir -p bin lib

# Copy CLI
cp ../../aethex.js ./bin/aethex.js

# Make it executable
chmod +x ./bin/aethex.js

# Copy compiler
cp ../../aethex-compiler.js ./lib/compiler.js

# Install dependencies
npm install

# Create README
cp ../../README.md ./README.md
cp ../core/LICENSE ./LICENSE
```

### 2. Test Locally

```bash
# Test core package
cd packages/core
node -e "const {Passport, SafeInput} = require('./index.js'); console.log('✓ Core works')"

# Test CLI package
cd ../cli
npm link
aethex --version
```

### 3. Publish to npm

#### Core Package (Publish First)

```bash
cd packages/core

# Dry run to see what will be published
npm publish --dry-run

# Publish (public access for scoped packages)
npm publish --access public
```

#### CLI Package (Publish Second)

```bash
cd ../cli

# Dry run
npm publish --dry-run

# Publish
npm publish --access public
```

### 4. Verify Installation

```bash
# In a fresh directory
npm install -g @aethex.os/cli

# Test
aethex --version
aethex --help
```

## Version Updates

### Patch Release (Bug fixes)

```bash
cd packages/core
npm version patch
npm publish

cd ../cli
npm version patch
npm publish
```

### Minor Release (New features)

```bash
npm version minor
npm publish
```

### Major Release (Breaking changes)

```bash
npm version major
npm publish
```

## npmjs.com Package Pages

After publishing, your packages will be available at:

- **@aethex.os/core**: https://www.npmjs.com/package/@aethex.os/core
- **@aethex.os/cli**: https://www.npmjs.com/package/@aethex.os/cli

## Usage for End Users

Once published, users can install via:

```bash
# Install CLI globally
npm install -g @aethex.os/cli

# Use the CLI
aethex compile myfile.aethex

# Install core library (for projects)
npm install @aethex.os/core
```

## Troubleshooting

### Authentication Issues

```bash
# Login again
npm logout
npm login
```

### Permission Denied

```bash
# Make sure you're a member of @aethex.os organization
npm access ls-collaborators @aethex.os/core
```

### Tagging Releases

```bash
# Tag a specific version
npm dist-tag add @aethex.os/cli@1.0.1 latest

# List tags
npm dist-tag ls @aethex.os/cli
```

## Automated Publishing (GitHub Actions)

Create `.github/workflows/publish.yml`:

```yaml
name: Publish to npm

on:
  release:
    types: [created]

jobs:
  publish:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
          registry-url: 'https://registry.npmjs.org'

      - name: Publish @aethex.os/core
        run: |
          cd packages/core
          npm publish --access public
        env:
          NODE_AUTH_TOKEN: ${{ secrets.NPM_TOKEN }}

      - name: Publish @aethex.os/cli
        run: |
          cd packages/cli
          npm install
          npm publish --access public
        env:
          NODE_AUTH_TOKEN: ${{ secrets.NPM_TOKEN }}
```

Add `NPM_TOKEN` to your GitHub repository secrets.

## Maintenance

### Deprecating Old Versions

```bash
npm deprecate @aethex.os/cli@1.0.1 "Please upgrade to 1.1.0"
```

### Unpublishing (Use Carefully!)

```bash
# Can only unpublish within 72 hours
npm unpublish @aethex.os/cli@1.0.1
```

## Support

- **Issues**: https://github.com/aethex/aethex-lang/issues
- **Docs**: https://aethex.dev/lang
- **Email**: support@aethex.dev
